# -*- coding: utf-8 -*-
"""
********************************
@Time     :2020/7/10 21:10
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :test_mul.py
@Software :PyCharm
********************************
"""
import unittest
from libs.ddt import ddt, data
from scripts.parser_excel import ParserExcel
from scripts.parser_config import parser_config
from scripts.parser_log import log
from scripts.handle_request import HandleRequest
from scripts.handle_context import HandleContext


@ddt
class TestLogin(unittest.TestCase):
    """测试登录功能"""
    parser_excel = ParserExcel(sheet_name='login')
    cases_list = parser_excel.read_data()

    @classmethod
    def setUpClass(cls) -> None:
        log.info('\n{:*^80s}'.format('开始执行登录功能用例'))
        cls.send_request = HandleRequest()

    @classmethod
    def tearDownClass(cls) -> None:
        log.info('\n{:*^80s}\n'.format('执行登录功能用例结束'))
        cls.send_request.close()

    @data(*cases_list)
    def test_login(self, data_namedtuple):
        case_id = data_namedtuple.case_id
        title = data_namedtuple.title
        url = parser_config('api', 'prefix_url')+data_namedtuple.url
        params = HandleContext.login_parameter(data_namedtuple.params)
        resp = self.send_request(
            method=data_namedtuple.method,
            url=url,
            data=params
        )
        try:
            self.assertEqual(
                data_namedtuple.expected,
                resp.text,
                msg='测试{}失败'.format(title)
            )
        except AssertionError as e:
            log.error('\n{},执行结果：{}，具体异常：{}'.format(title, 'Fail', e))
            self.parser_excel.write_data(row=case_id+1,
                                         actual=resp.text,
                                         result=parser_config('msg', 'fail'))
            raise e
        else:
            log.info('\n{},执行结果：{}'.format(title, 'Pass'))
            self.parser_excel.write_data(row=case_id+1,
                                         actual=resp.text,
                                         result=parser_config('msg', 'pass'))


if __name__ == '__main__':
    unittest.main()
