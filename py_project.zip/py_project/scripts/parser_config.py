# -*- coding: utf-8 -*-
"""
********************************
@Time     :2020/7/10 21:35
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :parser_config.py
@Software :PyCharm
********************************
"""
import os
from configparser import ConfigParser

from scripts.constants import CONFIGS_PATH
from scripts.constants import CONFIGS_DIR


class ParserConfig(ConfigParser):
    """
    parser config file
    """
    def __init__(self, filename=None):
        super().__init__()
        self.filename = filename

    def __call__(self, section=None, option=None, is_eval=False, is_bool=False):

        self.read(self.filename, encoding='utf-8')

        if isinstance(is_bool, bool):
            if is_bool:
                return self.getboolean(section, option)

        data = self.get(section, option)
        if data.isdigit():
            return int(data)
        try:
            return float(data)
        except ValueError as e:
            pass
        if isinstance(is_eval, bool):
            if is_eval:
                return eval(data)
        return data

    @classmethod
    def write_config(cls, data, filename):
        """write data ti config file"""
        one_config = cls(filename=filename)
        for key in data:
            one_config[key] = data[key]
        filename = os.path.join(CONFIGS_DIR, filename)
        with open(filename, mode='w', encoding='utf-8') as file:
            one_config.write(file)


parser_config = ParserConfig(filename=CONFIGS_PATH)

if __name__ == '__main__':
    data = {'admin_user': {'Id': 10, 'regname': 'admin_user', 'mobilephone': '15105438762', 'pwd': '123456'}, 'invest_user': {'Id': 11, 'regname': 'invest_user', 'mobilephone': '13606725143', 'pwd': '123456'}, 'loan_user': {'Id': 12, 'regname': 'loan_user', 'mobilephone': '13197415286', 'pwd': '123456'}}

    # parser_config = ParserConfig()
    # print(parser_config('mysql', 'database'))
    # print(parser_config('project', 'url'))
    ParserConfig.write_config(data, 'test1.conf')

