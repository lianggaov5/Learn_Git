# -*- coding: utf-8 -*-
"""
********************************
@Time     :2020/7/17 21:59
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :handle_context.py
@Software :PyCharm
********************************
"""
import re

from scripts.handle_mysql import HandleMysql
from scripts.parser_config import ParserConfig
from scripts.constants import USERS_ACCOUNT_CONFIG_PATH


class HandleContext:
    do_config = ParserConfig(filename=USERS_ACCOUNT_CONFIG_PATH)
    unregistered_tel_pattern = re.compile(r'\${unregistered_tel}')
    registered_tel_pattern = re.compile(r'\${registered_tel}')
    invest_user_tel_pattern = re.compile(r'\${invest_user_tel}')
    invest_user_pwd_pattern = re.compile(r'\${invest_user_pwd}')

    @classmethod
    def unregistered_tel_replace(cls, data):
        """unregister tel replace"""
        do_mysql = HandleMysql()
        if re.search(cls.unregistered_tel_pattern, data):
            data = re.sub(cls.unregistered_tel_pattern,
                          do_mysql.create_unregistered_tel(),
                          data)
        do_mysql.close()
        return data

    @classmethod
    def registered_tel_replace(cls, data):
        """registered tel replace"""
        do_mysql = HandleMysql()
        sql = 'SELECT MobilePhone FROM `member` LIMIT 0, 1;'
        if re.search(cls.registered_tel_pattern, data):
            data = re.sub(cls.registered_tel_pattern,
                          do_mysql(sql)['MobilePhone'],
                          data)
        do_mysql.close()
        return data

    @classmethod
    def invest_tel_replace(cls, data):
        if re.search(cls.invest_user_tel_pattern, data):
            data = re.sub(cls.invest_user_tel_pattern,
                          str(cls.do_config('invest_user', 'mobilephone')),
                          data)
        return data

    @classmethod
    def invest_pwd_replace(cls, data):
        if re.search(cls.invest_user_pwd_pattern, data):
            data = re.sub(cls.invest_user_pwd_pattern,
                          str(cls.do_config('invest_user', 'pwd')),
                          data)
        return data

    @classmethod
    def register_parameter(cls, data):
        """register function parameter"""
        data = cls.unregistered_tel_replace(data)
        data = cls.registered_tel_replace(data)
        return data

    @classmethod
    def login_parameter(cls, data):
        """login function parameter"""
        data = cls.registered_tel_replace(data)
        data = cls.unregistered_tel_replace(data)
        return data

    @classmethod
    def recharge_parameter_replace(cls, data):
        """recharge function parameter"""
        data = cls.invest_tel_replace(data)
        data = cls.invest_pwd_replace(data)
        return data


if __name__ == '__main__':
    target_str = '{"mobilephone":"${unregistered_tel}","pwd":"123456"}'
    target_str_2 = '{"mobilephone":"${registered_tel}","pwd":"123456"}'
    target_str_3 = '{"mobilephone":"${invest_user_tel}","pwd":"${invest_user_pwd}"}'
    # print(HandleContext.unregistered_tel_replace(target_str))
    # print(HandleContext.registered_tel_replace(target_str_2))
    print(HandleContext.recharge_parameter_replace(target_str_3))
