# -*- coding: utf-8 -*-
"""
********************************
@Time     :2020/7/14 22:00
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :parser_log.py
@Software :PyCharm
********************************
"""
import logging
from logging.handlers import RotatingFileHandler
from scripts.constants import LOG_PATH


class ParserLog:
    """
    record log
    """
    def __init__(self):
        self.log = logging.getLogger('Case')
        self.log.setLevel('DEBUG')
        self.file_handle = RotatingFileHandler(filename=LOG_PATH,
                                               maxBytes=1024*1024*3,
                                               backupCount=3,
                                               encoding='utf-8')
        self.file_handle.setLevel('INFO')
        self.log_formatter = logging.Formatter("%(asctime)s - [%(levelname)s] - %(module)s  - %(name)s"
                                  " - [行数]:%(lineno)d - [日志信息]:%(message)s")
        self.file_handle.setFormatter(self.log_formatter)
        self.log.addHandler(self.file_handle)

    def get_log(self):
        return self.log


log = ParserLog()
log = log.get_log()

if __name__ == '__main__':
    pass
