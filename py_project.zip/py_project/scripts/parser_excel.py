# -*- coding: utf-8 -*-
"""
********************************
@Time     :2020/7/10 20:35
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :parser_excel.py
@Software :PyCharm
********************************
"""
from openpyxl import load_workbook
from collections import namedtuple
from scripts.constants import DATA_PATH
from scripts.parser_config import parser_config


class ParserExcel:
    """
    parser excel
    """

    def __init__(self, file_name=DATA_PATH, sheet_name=None):
        self.file_name = file_name
        self.sheet_name = sheet_name
        self.wb = load_workbook(self.file_name)
        if self.sheet_name is None:
            self.ws = self.wb.active
        else:
            self.ws = self.wb[sheet_name]

    def read_data(self):
        """
        read all the data in the form
        :return:
        """
        case_list = []
        sheet_head_title = tuple(self.ws.iter_rows(max_row=self.ws.min_row, values_only=True))[0]
        Cases = namedtuple('Cases', sheet_head_title)
        for row_data in self.ws.iter_rows(min_row=self.ws.min_row+1, values_only=True):
            case_list.append(Cases(*row_data))

        return case_list

    def write_data(self, row, actual, result):
        """
        write the data in a cell of a sheet
        :param row:
        :param actual:
        :param result:
        :return:
        """
        other_wb = load_workbook(self.file_name)
        other_ws = other_wb[self.sheet_name]
        if isinstance(row, int) and other_ws.min_row+1 <= row <= other_ws.max_row:
            other_ws.cell(row=row, column=parser_config('excel', 'actual_col'), value=actual)
            other_ws.cell(row=row, column=parser_config('excel', 'result_col'), value=result)
            other_wb.save(self.file_name)
        else:
            print('传入的行号有误')


if __name__ == '__main__':
    do_excel = ParserExcel(file_name=DATA_PATH, sheet_name='register')
    print(do_excel.read_data())
    # print(do_excel.write_data(2, 10, 'pass'))
    pass
