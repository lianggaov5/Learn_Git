# -*- coding: utf-8 -*-
"""
********************************
@Time     :2020/7/16 6:16
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :handle_mysql.py
@Software :PyCharm
********************************
"""
import random
import string

import pymysql

from scripts.parser_config import parser_config


class HandleMysql:
    """
    handle mysql
    """

    def __init__(self):
        self.conn = pymysql.connect(host=parser_config('database', 'host'),
                                    user=parser_config('database', 'user'),
                                    password=str(parser_config('database', 'password')),
                                    database=parser_config('database', 'db'),
                                    port=parser_config('database', 'port'),
                                    charset=parser_config('database', 'charset'),
                                    cursorclass=pymysql.cursors.DictCursor)
        self.cursor = self.conn.cursor()

    def __call__(self, sql, args=None, is_more=False):
        """

        :param sql:
        :param args:
        :param is_more:
        :return:
        """
        self.cursor.execute(sql, args)
        self.conn.commit()
        if is_more:
            res = self.cursor.fetchall()
        else:
            res = self.cursor.fetchone()
        return res

    def close(self):
        """
        close connect
        :return:
        """
        self.cursor.close()
        self.conn.close()

    @staticmethod
    def generate_random_tel():
        """ generate a random tel number"""
        previous_three_num = ['131', '177', '188', '136', '151']
        last_eight_num = ''.join(random.sample(string.digits, 8))
        return random.choice(previous_three_num)+last_eight_num

    def is_exist_tel(self, tel):
        """whether tel exists in the database"""
        sql = 'SELECT MobilePhone FROM `member` WHERE MobilePhone="%s"'
        if self(sql, args=tel):
            return True
        else:
            return False

    def create_unregistered_tel(self):
        generate_tel = self.generate_random_tel()
        # while self.is_exist_tel(generate_tel):
        #     generate_tel = self.generate_random_tel()
        while True:
            if not self.is_exist_tel(generate_tel):
                break
            generate_tel = self.generate_random_tel()
        return generate_tel


if __name__ == '__main__':
    sql_1 = 'SELECT MobilePhone FROM `member` WHERE MobilePhone = %s;'
    # sql_1 = 'SELECT Id FROM `member` WHERE LeaveAmount > %s LIMIT 0, 10;'
    sql_2 = 'SELECT MobilePhone FROM `member` LIMIT 0, 1;'

    handle_mysql = HandleMysql()
    # result = handle_mysql(sql_2, is_more=True)
    result = handle_mysql(sql=sql_1, args=("15556075395",), is_more=True)
    result = handle_mysql(sql=sql_2)
    print(result)
    # print(handle_mysql.generate_random_tel())
    # print(handle_mysql.create_unregistered_tel())

    handle_mysql.close()
    