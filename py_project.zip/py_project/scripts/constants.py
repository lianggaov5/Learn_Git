# -*- coding: utf-8 -*-
"""
********************************
@Time     :2020/7/10 20:03
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :constants.py
@Software :PyCharm
********************************
"""
import os

# __file__ 固定变量
# 获取项目根目录路径
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# 封装脚本的目录
SCRIPTS_DIR = os.path.join(BASE_DIR, 'scripts')
# 配置文件的目录
CONFIGS_DIR = os.path.join(BASE_DIR, 'configs')
# 测试数据的目录
DATA_DIR = os.path.join(BASE_DIR, 'datas')
# 第三方库的目录
LIBS_DIR = os.path.join(BASE_DIR, 'libs')
# 日志文件的目录
LOGS_DIR = os.path.join(BASE_DIR, 'logs')
# 测试报告文件的目录
REPORTS_DIR = os.path.join(BASE_DIR, 'reports')
# 单元测试用例、单元测试类的目录
CASES_DIR = os.path.join(BASE_DIR, 'cases')

# 测试用例的路径
DATA_PATH = os.path.join(DATA_DIR, 'test_api_case.xlsx')
# 配置文件的路径
CONFIGS_PATH = os.path.join(CONFIGS_DIR, 'test_case.conf')
# 测试报告文件的路径
REPORTS_PATH = os.path.join(REPORTS_DIR, 'test_result')
# 日志文件的路径
LOG_PATH = os.path.join(LOGS_DIR, 'test_case.log')
# 用户账号文件路径
USERS_ACCOUNT_CONFIG_PATH = os.path.join(CONFIGS_DIR, 'users_account.conf')

if __name__ == '__main__':
    print(BASE_DIR)
    print(SCRIPTS_DIR)
    print(REPORTS_PATH)
    print(DATA_PATH)


