# -*- coding: utf-8 -*-
"""
********************************
@Time     :2020/7/15 22:24
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :handle_request.py
@Software :PyCharm
********************************
"""
import json

import requests

from scripts.parser_log import log


class HandleRequest:
    """
    handle request
    """
    def __init__(self):
        self.one_session = requests.Session()

    def __call__(self, method, url, data=None, is_json=False, **kwargs):
        method = method.lower()
        if isinstance(data, str):
            try:
                data = json.loads(data, encoding='utf-8')
            except Exception as e:
                log.error("将json数据转换成python异常\n")
                data = eval(data)
        if method == "get":
            resp = self.one_session.get(url=url, params=data, **kwargs)
        elif method == "post":
            if is_json:
                resp = self.one_session.post(url=url, json=data, **kwargs)
            else:
                resp = self.one_session.post(url=url, data=data, **kwargs)
        else:
            res = None
            log.error('不支持{}请求方法'.format(method))
        return resp

    def close(self):
        self.one_session.close()


if __name__ == '__main__':
    # 1.构造url
    login_url = "http://192.168.65.128:8888/futureloan/mvc/api/member/login"
    recharge_url = "http://192.168.65.128:8888/futureloan/mvc/api/member/recharge"

    # 2.创建请求参数
    login_params = {
        "mobilephone": "15556075395",
        "pwd": "Gl123456"
    }

    recharge_params = {
        "mobilephone": "15556075395",
        "amount": 100
    }
    # 3.向服务器发送请求
    send_request = HandleRequest()
    login_resp = send_request("Post", login_url, login_params)
    print(login_resp.text)
    recharge_resp = send_request("Post", recharge_url, recharge_params)
    print(recharge_resp.text)
    # 关闭会话
    send_request.close()

