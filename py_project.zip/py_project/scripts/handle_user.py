# -*- coding: utf-8 -*-
"""
********************************
@Time     :2020/7/18 10:15
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :handle_user.py
@Software :PyCharm
********************************
"""
from scripts.handle_request import HandleRequest
from scripts.handle_mysql import HandleMysql
from scripts.parser_config import ParserConfig
from scripts.constants import CONFIGS_PATH, USERS_ACCOUNT_CONFIG_PATH


def create_new_user(regname, pwd='123456'):
    """
    create a nwe user
    :param regname:
    :param pwd:
    :return:
    """
    send_request = HandleRequest()
    handle_mysql = HandleMysql()
    parser_config = ParserConfig(filename=CONFIGS_PATH)

    sql = 'SELECT `Id` FROM `member` WHERE MobilePhone=%s'
    while True :
        tel = handle_mysql.create_unregistered_tel()
        data = {'mobilephone': tel, 'pwd' : pwd, 'regname': regname}
        send_request(
            method='post',
            url=parser_config('api', 'prefix_url') + r'/member/register',
            data=data
        )
        res = handle_mysql(sql=sql, args=(tel,))
        if res:
            user_id = res['Id']
            break
    user_dict = {
        regname: {
            'Id': user_id,
            'regname': regname,
            'mobilephone': tel,
            'pwd' : pwd
        }
    }
    handle_mysql.close()
    send_request.close()
    return user_dict


def generate_users_config():
    """
    generate three user config
    :return:
    """
    user_data_dict = {}
    user_data_dict.update(create_new_user('admin_user'))
    user_data_dict.update(create_new_user('invest_user'))
    user_data_dict.update(create_new_user('loan_user'))
    ParserConfig.write_config(user_data_dict, USERS_ACCOUNT_CONFIG_PATH)


if __name__ == '__main__':
    generate_users_config()