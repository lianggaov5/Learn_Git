# -*- coding: utf-8 -*-
"""
********************************
@Time     :2020/7/10 22:53
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :run_test.py
@Software :PyCharm
********************************
"""
import unittest
import os
from datetime import datetime

from HTMLTestRunnerNew import HTMLTestRunner
# from cases.test_register import TestRegister
# from cases.test_login import TestLogin
from scripts.constants import CASES_DIR
from scripts.constants import REPORTS_PATH, USERS_ACCOUNT_CONFIG_PATH
from scripts.handle_user import generate_users_config

if not os.path.exists(USERS_ACCOUNT_CONFIG_PATH):
    generate_users_config()

# one_loader = unittest.TestLoader()
# test_class_tuple = (
#     one_loader.loadTestsFromTestCase(TestRegister),
#     one_loader.loadTestsFromTestCase(TestLogin)
# )
# one_suite = unittest.TestSuite(tests=test_class_tuple)
one_suite = unittest.defaultTestLoader.discover(CASES_DIR)

report_html_name = REPORTS_PATH+'_'+datetime.strftime(datetime.now(), '%Y%m%d-%H%M%S')+'.html'
with open(report_html_name, mode='wb') as save_to_file:
    one_runner = HTMLTestRunner(stream=save_to_file,
                                verbosity=2,
                                title='金融类项目API测试报告',
                                description='测试注册、登录、充值、提现、等功能操作',
                                tester='Jack')
    one_runner.run(one_suite)
