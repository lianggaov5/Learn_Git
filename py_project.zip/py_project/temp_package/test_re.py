# -*- coding: utf-8 -*-
"""
********************************
@Time     :2020/7/17 6:26
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :test_re.py
@Software :PyCharm
********************************
"""
import re

target_str = '{"mobilephone": "${not_existed_tel}", "pwd": "123456", "regname": "${not_existed_tel}"}'
not_existed_tel_pattern = re.compile(r"\${not_existed_tel}")


def not_existed_tel(data):
    if re.search(not_existed_tel_pattern, data):
        data = re.sub(not_existed_tel_pattern, '15556075395', data)
    return data


if __name__ == '__main__':
    print(not_existed_tel(target_str))