# -*- coding: utf-8 -*-
"""
********************************
@Time     :2020/7/15 21:20
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :send_request.py
@Software :PyCharm
********************************
"""
import requests
import json
# demo1
# url = "http://192.168.65.128:8888/futureloan/mvc/api/member/login"
# param = {"mobilephone": "15556075395", "pwd": "Gl123456"}
# json_param = '{"mobilephone": "15556075395", "pwd": "Gl123456"}'
# # headers = {
# #     "user-agent": "Mozilla/5.0 gl/0.0.1",
# #     "Content-Type": "application/json"
# # }
# # resp = requests.get(url=url, params=param)
# resp = requests.post(url=url, data=json.loads(json_param, encoding="utf-8"))
#
# print('{}'.format(resp.status_code))
# print('{}'.format(resp.cookies))
# print('{}'.format(resp.headers))
# print('{}, {}'.format(type(resp.text), resp.text))
# print('{}, {}'.format(type(resp.json()), resp.json()))

# demo2
login_url = "http://192.168.65.128:8888/futureloan/mvc/api/member/login"
recharge_url = "http://192.168.65.128:8888/futureloan/mvc/api/member/recharge"
login_param = {"mobilephone": "15556075395", "pwd": "Gl123456"}
recharge_param = {"mobilephone": "15556075395", "amount": "100"}

# login_resp = requests.post(url=login_url, data=login_param)
# print(login_resp.text)
# login_cookie = login_resp.cookies
# print(login_cookie)
# recharge_resp = requests.post(url=recharge_url, data=recharge_param, cookies=login_cookie)
# print(recharge_resp.text)

# demo3
global_session = requests.Session()
login_resp = global_session.post(url=login_url, data=login_param)
print(login_resp.text)
recharge_resp = global_session.post(url=recharge_url, data=recharge_param)
print(recharge_resp.text)
global_session.close()