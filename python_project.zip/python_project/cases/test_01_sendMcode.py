# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/6/14 16:07
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :test_01_sendMcode.py
@Software :PyCharm
********************************
"""
import unittest
import inspect
import json

from libs.ddt import ddt, data
from suds.client import Client

from scripts.handle_excel import HandleExcel
from scripts.handle_config import do_config
from scripts.handle_log import HandleLog
from scripts.constants import TEST_DATA_FILE_PATH
# from scripts.handle_context import Context

do_log = HandleLog().get_logger()


@ddt
class TestSendMsgCode(unittest.TestCase):
    """
    测试注册功能
    """
    do_excel = HandleExcel(TEST_DATA_FILE_PATH, "sendMCode")
    cases_list = do_excel.get_cases()  # 获取所有的用例，返回一个嵌套命名元组的列表

    @classmethod
    def setUpClass(cls):
        """
        重写父类的类方法，在实例方法执行之前会被调用一次
        在所有用例执行之前会被执行
        :return:
        """
        do_log.info("\n{:=^40s}".format("开始执行注册功能用例"))

    @classmethod
    def tearDownClass(cls):
        """
        重写父类的类方法
        所有用例执行之后，会被调用一次
        :return:
        """
        do_log.info("\n{:=^40s}\n".format("注册功能用例执行结束"))

    @data(*cases_list)   # 装饰实例方法
    def test_send_msg_code(self, data_namedtuple):
        """
        测试注册功能
        :param data_namedtuple:
        :return:
        """
        print("\nRunning Test Method:{}".format(inspect.stack()[0][3]))
        do_log.info("\nRunning Test Method:{}".format(inspect.stack()[0][3]))

        new_url = do_config.get("project", "url") + data_namedtuple.url

        new_data = json.loads(data_namedtuple.datas)

        # 生成一个webservices对象
        client = Client(new_url)
        response = client.service.sendMCode(new_data)

        run_success_msg = do_config("msg", "success_result")
        run_fail_msg = do_config("msg", "fail_result")

        print("expect_result:{}".format(data_namedtuple.expected))
        print("real_result:{}".format(str(response)))

        try:
            self.assertEqual(str(response), data_namedtuple.expected,
                             msg="测试{}注册失败".format(data_namedtuple.title))
        except AssertionError as e:
            print("具体异常信息为{}".format(e))
            do_log.error("{},执行结果:{}\n具体异常信息:{}\n".format(data_namedtuple.title, run_fail_msg, e))
            self.do_excel.write_case(row=data_namedtuple.case_id+1,
                                     actual=str(response),
                                     result=run_fail_msg)
            raise e
        else:
            self.do_excel.write_case(row=data_namedtuple.case_id+1,
                                     actual=str(response),
                                     result=run_success_msg)


if __name__ == "__main__":
    unittest.main()

