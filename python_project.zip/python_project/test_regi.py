# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/6/14 15:23
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :test01.py
@Software :PyCharm
********************************
"""
import json
from suds.client import Client

# 短信验证码url
user_url = "http://120.24.235.105:9010/finance-user_info-war-1.0/ws/financeUserInfoFacade.ws?wsdl"
# 参数为url,生成一个webservices对象
client = Client(user_url)
# 打印webservices中的所有接口信息
# print(client)
# client_ip：ip地址  mobile：手机号  tmpl_id：短信模板
msg_data = '{"client_ip": "192.168.11.23", "mobile": "18860402111", "tmpl_id": 1}'
msg_data = json.loads(msg_data)
# 调用发送短信接口
result = client.service.sendMCode(msg_data)
# 打印响应结果
print(type(str(result)))
print(str(result))
pass
