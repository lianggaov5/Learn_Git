# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/6/14 17:29
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :handle_context.py
@Software :PyCharm
********************************
"""
import re

from scripts.handle_mysql import HandleMysql
from scripts.handle_config import HandleConfig
from scripts.constants import CONFIGS_USER_FILE_PATH
# from cases.test_05_invest import LOAN_ID  # 多次导入相同的模块，只有第一次生效
# 只能实现单项导入

do_config = HandleConfig(CONFIGS_USER_FILE_PATH)


class Context:
    """
    实现参数化、反射功能   使用反射解决了循环导入和不能实时更新的问题
    """
    not_existed_tel_pattern = re.compile(r"\$\{not_existed_tel\}")   # 配置${not_existed_tel}的正则表达式
    invest_user_tel_pattern = re.compile(r"\$\{invest_user_tel\}")
    fixed_pwd_pattern = re.compile(r"\$\{fixed_user_pwd\}")               # 配置固定的密码
    not_existed_regname_pattern = re.compile(r"\$\{not_existed_regname\}")
    admin_user_tel_pattern = re.compile(r"\$\{admin_user_tel\}")
    borrow_user_id_pattern = re.compile(r"\$\{borrow_user_id\}")
    loan_id_pattern = re.compile(r"\$\{loan_id\}")
    invest_user_id_pattern = re.compile(r"\$\{invest_user_id\}")

    @classmethod
    def not_existed_tel_replace(cls, data):
        """
        替换未注册的手机号
        :param data:
        :return:
        """
        do_mysql = HandleMysql()
        # 查询pattern模式对象是否在原始字符串中存在,存在则匹配
        if re.search(cls.not_existed_tel_pattern, data):
            # 生成未注册的手机号
            not_existed_tel = do_mysql.create_not_existed_phone()
            # sub中第一个参数为pattern模式对象,第二个参数为需要替换的值,第三个参数为原始字符串
            data = re.sub(cls.not_existed_tel_pattern, not_existed_tel, data)

        do_mysql.close()
        return data

    @classmethod
    def fixed_pwd_replace(cls, data):
        """
        替换密码
        :param data:
        :return:
        """
        if re.search(cls.fixed_pwd_pattern, data):
            data = re.sub(cls.fixed_pwd_pattern, "Gl123456", data)
        return data

    @classmethod
    def invest_user_tel_replace(cls, data):
        """
        替换投资人的手机号
        :param data:
        :return:
        """
        # 查询pattern模式对象是否在原始字符串中存在
        if re.search(cls.invest_user_tel_pattern, data):
            # sub中第一个参数为pattern模式对象,第二个参数为需要替换的值,第三个参数为原始字符串
            # sub中第二个和第三个参数一定要为字符串类型
            data = re.sub(cls.invest_user_tel_pattern, str(do_config("invest_user", "mobilephone")), data)
        return data

    @classmethod
    def admin_user_tel_replace(cls, data):
        """
        管理员手机号码的替换
        :param data:
        :return:
        """
        if re.search(cls.admin_user_tel_pattern, data):
            data = re.sub(cls.admin_user_tel_pattern, str(do_config("admin_user", "mobilephone")), data)
        return data

    @classmethod
    def borrow_user_id_replace(cls, data):
        if re.search(cls.borrow_user_id_pattern, data):
            replace_str = str(do_config("borrow_user", "id"))
            data = re.sub(cls.borrow_user_id_pattern, replace_str, data)
        return data

    @classmethod
    def loan_id_replace(cls, data):
        if re.search(cls.loan_id_pattern, data):
            # 第一个参数为对象或类，第二个参数为字符串类型的属性名
            # 获取类或对象的实例属性或类属性
            # getattr(对象, 字符串类型的属性名, 属性值)
            # 类似于java中的反射
            loan_id = getattr(cls, "loan_id")
            data = re.sub(cls.loan_id_pattern, str(loan_id), data)
            # data = re.sub(cls.loan_id_pattern, "1111", data)
        return data

    @classmethod
    def invest_user_id_replace(cls, data):
        """
        投资用户的id的替换
        :param data:
        :return:
        """
        if re.search(cls.invest_user_id_pattern, data):
            replace_str = str(do_config("invest_user", "id"))
            data = re.sub(cls.invest_user_id_pattern, replace_str, data)
        return data

    @classmethod
    def register_parameter(cls, data):
        """
        实现注册功能的参数化
        :param self:
        :param data:
        :return:
        """
        # 先替换的未注册的手机号
        data = cls.not_existed_tel_replace(data)
        # 替换固定参数化的密码
        data = cls.fixed_pwd_replace(data)
        # 再替换已注册的手机号
        data = cls.invest_user_tel_replace(data)
        return data

    @classmethod
    def login_parameter(cls, data):
        """
        实现登陆功能的参数化
        :param data:
        :return:
        """
        # 先替换的未注册的手机号
        data = cls.not_existed_tel_replace(data)
        # 替换固定参数化的密码
        data = cls.fixed_pwd_replace(data)
        # 再替换已注册的手机号
        data = cls.invest_user_tel_replace(data)

        return data

    @classmethod
    def recharge_parameter(cls, data):
        """
        实现充值功能的参数化
        :param data:
        :return:
        """
        # 先替换的未注册的手机号
        data = cls.not_existed_tel_replace(data)
        # 替换固定参数化的密码
        data = cls.fixed_pwd_replace(data)
        # 再替换已注册的手机号
        data = cls.invest_user_tel_replace(data)

        return data

    @classmethod
    def add_parameter(cls, data):
        """
        实现加标功能的参数化
        :param data:
        :return:
        """
        # 替换参数化的admin_user_tel
        data = cls.admin_user_tel_replace(data)
        # 替换参数化的borrow_user_id
        data = cls.borrow_user_id_replace(data)
        # 替换固定参数化的密码
        data = cls.fixed_pwd_replace(data)
        return data

    @classmethod
    def invest_parameter(cls, data):
        """
        实现登陆功能的参数化
        :param data:
        :return:
        """
        # 替换参数化的admin_user_tel
        data = cls.admin_user_tel_replace(data)
        # 替换参数化的borrow_user_id
        data = cls.borrow_user_id_replace(data)
        # 替换参数化的投资用户id
        data = cls.invest_user_id_replace(data)
        # 替换参数化的投资人手机号
        data = cls.invest_user_tel_replace(data)
        # 替换固定参数化的密码
        data = cls.fixed_pwd_replace(data)
        # 替换参数化的标的loan_id
        data = cls.loan_id_replace(data)
        return data


if __name__ == '__main__':
    target_str1 = '{"mobilephone":"${not_existed_tel}","pwd":"${fixed_user_pwd}","regname":"Tom"}'
    target_str2 = '{"mobilephone":"${invest_user_tel}","pwd":"${fixed_user_pwd}","regname":""}'
    target_str3 = '{"mobilephone":"${invest_user_tel}","amount":0.01}'
    target_str4 = '{"memberId":"${invest_user_id}","password":"${fixed_user_pwd}","loanId":"${load_id}","amount":500}'
    one_context = Context()
    # print(one_context.register_parameter(target_str1))
    # print(one_context.register_parameter(target_str1))
    # print(one_context.register_parameter(target_str1))
    # print(one_context.invest_user_tel_replace(target_str2))
    # print(one_context.recharge_parameter(target_str3))
    print(one_context.recharge_parameter(target_str4))