# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/6/14 15:20
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :handle_request.py
@Software :PyCharm
********************************
"""
from suds.client import Client
import json
from scripts.handle_log import HandleLog
from scripts.handle_config import do_config

do_log = HandleLog().get_logger()


class HandleRequest:
    """
    处理webservices请求
    """

    def __call__(self, url, method, data=None, is_json=False, **kwargs):

        # 判断data是否为json格式字符串，若是，转换成字典，不是，抛出异常
        if isinstance(data, str):
            try:
                data = json.loads(data)
            except Exception as e:
                # 调用日志器的error方法记录异常信息
                do_log.error("将json转换成python类型时，出现异常：{}".format(e))
                # 若data是字符串，不是json格式，用eval函数转换
                data = eval(data)
        client = Client(url)
        print(client)
        res = client.service.method(data)
        return res


do_request = HandleRequest()


if __name__ == '__main__':
    url = "http://120.24.235.105:9010/sms-service-war-1.0/ws/smsFacade.ws?wsdl"
    data = {"client_ip": "192.168.1.120", "mobile": "15556075222", "tmpl_id": 1}
    method = "sendMCode"
    do_request = HandleRequest()
    response = do_request(url, method, data, is_json=True)
    print(response)
