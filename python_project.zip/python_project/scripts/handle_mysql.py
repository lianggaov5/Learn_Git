# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/6/14 16:34
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :handle_mysql.py
@Software :PyCharm
********************************
"""
import random
import pymysql
import re

from scripts.handle_config import do_config


class HandleMysql:
    """
    处理数据库
    """
    not_existed_tel_pattern = re.compile(r"\$\{not_existed_phone\}")
    not_existed_regname_pattern = re.compile(r"\$\{not_existed_regname\}")

    def __init__(self):
        self.connect = pymysql.connect(
            host=do_config("database", "host"),
            port=do_config("database", "port", is_eval=True),
            user=do_config("database", "user"),
            password=do_config("database", "password"),
            db=do_config("database", "db"),
            charset=do_config("database", "charset"),
            cursorclass=pymysql.cursors.DictCursor
         )
        self.cursor = self.connect.cursor()

    def __call__(self, sql, args=None, is_more=False):
        """
         获取查询到的数据
        :param sql:sql语句
        :param args:sql语句的参数，传入序列类型
        :param is_more: True为多个，False为单个
        :return:返回字典类型或嵌套字典的列表
        """
        self.cursor.execute(sql, args)
        self.connect.commit()
        if is_more:
            # 获取多条记录
            result = self.cursor.fetchall()
        else:
            # 获取单条记录
            result = self.cursor.fetchone()
        return result

    def close(self):
        """
        关闭连接
        :return:
        """
        self.cursor.close()
        self.connect.close()

    @staticmethod
    def create_phone():
        """
        随机生成11位手机号
        :return:
        """
        top_three = ["131", "136", "138", "155", "183", "188"]
        last_eight = str(random.randint(10000000, 99999999))
        return random.choice(top_three) + last_eight   # random.choice() 参数为序列类型

    def is_existed_phone(self, phone):
        """
        判断给定的手机号是否在数据库中存在
        :param phone:
        :return:手机号在数据库中存在，返回True，否则返回False
        """
        sql = "select `MobilePhone` from future.`member` where `MobilePhone`=%s;"

        if self(sql, args=(phone,)):
            return True
        else:
            return False

    def create_not_existed_phone(self):
        """
        # 生成未注册的手机号
        :return:
        """
        while True:
            random_phone = self.create_phone()
            if not self.is_existed_phone(random_phone):
                break
        return random_phone
        # while self.is_existed_tel(random_phone):
        #     random_phone = self.create_phone()


do_mysql = HandleMysql()


if __name__ == '__main__':
    data = '{"mobilephone":"${not_existed_phone}","pwd":"123456","regname":"${not_existed_regname}"}'
    do_mysql = HandleMysql()
    print(do_mysql.create_not_existed_phone())

    do_mysql.close()