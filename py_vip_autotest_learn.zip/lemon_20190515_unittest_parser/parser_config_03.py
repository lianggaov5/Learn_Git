"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/17 18:37
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :parser_config_01.py
@Software :PyCharm
********************************
"""
# 利用代码实现配置文件的写入
from configparser import ConfigParser
# 1.创建配置解析器对象
config = ConfigParser()  # 没有读取对象时，config就相当于一个空字典

# 2、将需要写入配置文件中的数据组合成字典
datas = {
    "file path": {
        "cases_path": "mul_case.xlsx",
        "log_path": "record_run_results.txt"
    },
    "msg": {
        "success_result": "Pass",
        "fail_result": "Fail"
    },
    "excel": {
        "actual_col": "6",
        "result_col": "7"
    }
}
for key in datas:
    config[key] = datas[key]
    print(config[key])

# 3.保存到文件
with open("write_config.ini", "w") as file:
    config.write(file)

