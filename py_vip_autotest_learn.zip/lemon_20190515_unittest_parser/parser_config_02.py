"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/17 18:37
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :parser_config_01.py
@Software :PyCharm
********************************
"""
# 有很多变量写死了，比如excel文件名，记录日志的文件名、写入的行数等
# 可以将这些变量写到配置文件中，如果项目需求变更，只需要修改配置文件即可

# 一般配置文件的拓展名有：.conf、.ini等
# 配置文件是怎样的？
# section   片段/区域  [区域名]
# 区域名区分大小写，区域名不必遵守Python中的标识符命名规则
# option 相当于字典中的key
# 选项名不区分大小写，默认以小写存储，选项名不必遵守Python中的标识符命名规则
# value相当于字典中的value
# 给选项名赋值默认使用等号，也可使用英文中的冒号,等号和冒号两侧的空格可写可不写
from configparser import ConfigParser
# 1.创建配置解析器对象
config = ConfigParser()

# 2.指定读取的配置文件名  可以指定多个
read_file = config.read("test_case.conf", encoding="utf-8")

# 3.读取数据
# config 相当于嵌套字典的字典
config.sections()  # 返回区域名组成的一个列表

# 方法1 通过区域名+选项名来获取选项值
# print(config["file path"]["cases_path"])

# 方法2
config.get("file path", "cases_path")  # 字典中的get有区别

# 方法3
msg = config["msg"]  # 返回一个Section对象，相当于一个字典
# print(msg["success_result"])
for value in msg.values():   # <==> 遍历字典   msg.values()
    print("值为：{}，类型为：{}".format(value, type(value)))
pass
# 注意事项：
# 配置文件中的读取
# 从配置文中获取到的所有值都是字符串类型
# 可以使用int来转换，也可以使用eval函数
# 配置文件类中，提供了一个getint()、getfloat()、getboolean()
# getboolean()
# 1、yes、on、true都会被识别为True
# 0、False、no、off都会被识别为False
# getfloat() 将数字类型的字符串转换为float类型
# 如果是其他类型，比如列表、元组、字典只能使用eval()函数
# 配置文件中有一个DEFAULT默认区域，这个区域中保存的是所有区域中公共的数据
# 如果不显示定义DEFAULT，就是一个空字典

