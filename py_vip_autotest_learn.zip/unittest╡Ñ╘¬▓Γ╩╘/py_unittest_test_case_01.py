"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/1 8:52
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :math_operation_test_case.py
@Software :PyCharm
********************************
"""

import unittest  # 先导入模块
from unittest单元测试.py_unittest_math_operation_01 import MathOperation    # 再导入自定义模块
import inspect


class TestMul(unittest.TestCase):

    def test_two_positive_mul(self):
        # 查看当前运行的实例方法名称，用例根据实例方法名按照ascii码顺序运行
        print("\nRunning Test Method:{}".format(inspect.stack()[0][3]))
        real_result = MathOperation(2, 4).mul()
        expect_result = 8
        # 发生异常时，如果没有捕获异常，unittest框架会提示Tests failed
        # 发生异常时，如果捕获了异常，写入到日志记录器之后，未手动抛出，unittest框架会默认Tests passed，
        # 故需要手动抛出异常,使unittest框架知道发生了异常
        try:
            self.assertEqual(real_result, expect_result, msg="测试两个正数相乘失败")
        except AssertionError as e:
            print("写入异常信息到日志记录器")
            print("具体异常信息为{}".format(e))
            raise e

    def test_two_negative_mul(self):
        # 查看当前运行的实例方法名称
        print("\nRunning Test Method:{}".format(inspect.stack()[0][3]))
        real_result = MathOperation(-2, -3).mul()
        expect_result = 6
        try:
            self.assertEqual(real_result, expect_result, msg="测试两个负数相乘失败")
        except AssertionError as e:
            print("写入异常信息到日志记录器")
            print("具体异常信息为：{}".format(e))
            raise e

    def test_positive_negative_mul(self):
        # 查看当前运行的实例方法名称
        print("\nRunning Test Method:{}".format(inspect.stack()[0][3]))
        real_result = MathOperation(2, -3).mul()
        expect_result = -6
        try:
            self.assertEqual(real_result, expect_result, msg="测试一个正数和一个负数相乘失败")
        except AssertionError as e:
            print("写入异常信息到日志记录器")
            print("具体异常信息为：{}".format(e))
            raise e


if __name__ == "__main__":
        unittest.main()











