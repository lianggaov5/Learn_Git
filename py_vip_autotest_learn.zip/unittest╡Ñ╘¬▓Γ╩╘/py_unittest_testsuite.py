"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/5 21:08
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :py_unittest_testsuite.py
@Software :PyCharm
********************************
"""
import unittest
from unittest单元测试.py_unittest_test_case_04 import TestSub, TestDiv
from unittest单元测试 import py_unittest_test_case_04 as module01
from unittest单元测试 import py_unittest_assert_ways as module02
"""
# 1. 创建一个测试套件对象
one_suite = unittest.TestSuite()  # 实例化，创建一个测试套件对象

# 2. 加载用例
# 方法一 通过测试对象来加载用例，将实例方法名作为测试类的参数
# one_suite.addTest(TestSub("test_two_positive_sub"))  # 只能添加类的实例
# one_tuple = (TestSub("test_two_positive_sub"), TestSub("test_two_negative_sub"))
# one_suite.addTests(one_tuple)
# 方法二 通过测试类来批量加载测试用例
# one_loader = unittest.TestLoader()
# one_suite.addTest(one_loader.loadTestsFromTestCase(TestSub))
# one_suite.addTest(one_loader.loadTestsFromTestCase(TestDiv))
# 方法三  通过模块来批量加载测试用例
# 创建一个加载器
one_loader = unittest.TestLoader()
one_suite.addTest(one_loader.loadTestsFromModule(module01))

# 3. 执行用例
# 创建一个运行器对象  执行结果中一个“.”,代表成功执行一条用例，一个“F”代表执行一条用例失败
one_runner = unittest.TextTestRunner()
one_runner.run(one_suite)
"""
# 或者下面一种形式
# 1. 创建一个加载器，加载所有的模块
one_loader = unittest.TestLoader()
test_module_tuple = (one_loader.loadTestsFromModule(module01), one_loader.loadTestsFromModule(module02))

# 2. 创建测试套件
# 在创建测试套件时，将所有的测试模块所构成的元组传给TestSuite类
one_suite = unittest.TestSuite(tests=test_module_tuple)  # 调用父类的__init__方法

# 3. 执行用例
one_runner = unittest.TextTestRunner()
one_runner.run(one_suite)
