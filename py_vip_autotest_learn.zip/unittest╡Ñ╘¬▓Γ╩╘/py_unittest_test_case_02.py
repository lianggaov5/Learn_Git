# """
# -*- coding: utf-8 -*-
# ********************************
# @Time     :2019/5/1 8:52
# @Author   :gaoliang
# @Email    :337901080@qq.com
# @File     :math_operation_test_case.py
# @Software :PyCharm
# ********************************
# """
# # 解决每次都需要重复写打开和关闭文件的问题
# # setUp和tearDown分别每一个用例执行之前会被调用和每一个用例执行结束会被调用（重写父类的方法）
# import unittest  # 先导入模块
# from unittest单元测试.py_unittest_math_operation_01 import MathOperation    # 再导入自定义模块
# import inspect
#
#
# class TestAdd(unittest.TestCase):
#     """
#     定义一个加法类，执行两个数相加操作的测试用例
#     该加法类继承unittest框架中的TestCase类
#     继承TestCase类后,实例方法均要以test_开头
#     """
#     def setUp(self):
#         """
#         重写父类的方法
#         每一个用例执行之前会被调用
#         :return:
#         """
#         self.file_name = "record_run_result.txt"
#         print("打开【{}】文件".format(self.file_name))
#         self.file = open(self.file_name, mode="a", encoding="utf-8")
#         self.file.write("\n{:=^40s}\n".format("开始执行测试用例"))
#         print("{:=^40s}".format("开始执行用例"))
#
#     def test_two_positive_add(self):
#         # 查看当前运行的实例方法名称，用例根据实例方法名按照ascii码顺序运行
#         print("Running Test Method:{}".format(inspect.stack()[0][3]))
#         real_result = MathOperation(2, 4).add()
#         expect_result = 6
#         msg = "测试两个正数相加"
#         try:
#             self.assertEqual(expect_result, real_result, msg="测试两个正数相加失败")
#         except AssertionError as e:
#             self.file.write("{},执行结果:{}\n具体异常信息:{}\n".format(msg, "fail", e))
#             print("具体异常信息为{}".format(e))
#             raise e
#         else:
#             self.file.write("{},执行结果:{}\n".format(msg, "pass"))
#
#     def test_two_negative_add(self):
#         # 查看当前运行的实例方法名称
#         print("Running Test Method:{}".format(inspect.stack()[0][3]))
#         real_result = MathOperation(-2, -4).add()
#         expect_result = -6
#         msg = "测试两个负数相加"
#         try:
#             self.assertEqual(expect_result, real_result,  msg="测试两个负数相加失败")
#         except AssertionError as e:
#             self.file.write("{},执行结果:{}\n具体异常信息:{}\n".format(msg, "fail", e))
#             print("具体异常信息为{}".format(e))
#             raise e
#         else:
#             self.file.write("{},执行结果:{}\n".format(msg, "pass"))
#
#     def test_positive_negative_add(self):
#         # 查看当前运行的实例方法名称
#         print("Running Test Method:{}".format(inspect.stack()[0][3]))
#         real_result = MathOperation(2, -4).add()
#         expect_result = 2
#         msg = "测试一个正数和一个负数相加"
#         try:
#             self.assertEqual(expect_result, real_result,  msg="测试一个正数和一个负数相加失败")
#         except AssertionError as e:
#             self.file.write("{},执行结果:{}\n具体异常信息:{}\n".format(msg, "fail", e))
#             print("具体异常信息为{}".format(e))
#             raise e
#         else:
#             self.file.write("{},执行结果:{}\n".format(msg, "pass"))
#
#     def tearDown(self):
#         """
#         重写父类的方法
#         每一个用例执行结束会被调用
#         """
#         self.file.write("{:=^40s}\n".format("用例执行结束"))
#         print("{:=^40s}".format("用例执行结束"))
#         self.file.close()
#         print("关闭【{}】文件\n".format(self.file_name))
#
#     if __name__ == "__main__":
#         unittest.main()
#
#
#






list_1 = [1, 4, 3, 4, 3, 4, 1, 2, 6]
# for item in list_1:
#     if item == 4:
#         list_1.remove(item)
# print(list_1)
i = 0
while i < len(list_1):
    if list_1[i] == 4:
        list_1.remove(list_1[i])
    i += 1
print(list_1)