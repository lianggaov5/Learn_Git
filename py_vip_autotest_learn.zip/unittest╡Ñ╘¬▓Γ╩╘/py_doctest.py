# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/4/24 21:07
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :py_doctest.py
@Software :PyCharm
********************************
"""
import doctest


def add(a, b):
    """
    >>> add(1, 4)
    5
    >>> add(-1, -4)
    -5
    """
    return a+b


