"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/5 22:08
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :py_unittest_beautify_report01.py
@Software :PyCharm
********************************
"""
import unittest
from HtmlTestRunner import HTMLTestRunner
from unittest单元测试 import py_unittest_test_case_04 as module01
from unittest单元测试 import py_unittest_assert_ways as module02

# 1. 创建一个加载器，加载所有的模块
one_loader = unittest.TestLoader()
test_module_tuple = (one_loader.loadTestsFromModule(module01), one_loader.loadTestsFromModule(module02))

# 2. 创建测试套件
# 在创建测试套件时，将所有的测试模块所构成的元组传给TestSuite类
one_suite = unittest.TestSuite(tests=test_module_tuple)  # 调用父类的__init__方法

# 3. 执行用例
# one_runner = HTMLTestRunner(output="reports", report_name="测试结果集合", report_title="测试结果集标题")
one_runner = HTMLTestRunner(output="reports", report_name="测试结果集合", report_title="测试结果集标题",
                            combine_reports=True)
one_runner.run(one_suite)

# # 打开文件
# save_to_file = open("test_result.txt", mode="w", encoding="utf-8")
# # 将测试结果保存到文件中
# one_runner = unittest.TextTestRunner(stream=save_to_file, descriptions="测试结果集", verbosity=2)
# one_runner.run(one_suite)
# # 关闭文件
# save_to_file.close()

# with open("test_result.txt", mode="w", encoding="urf-8") as save_to_file:
#     one_runner = unittest.TextTestRunner(stream=save_to_file, descriptions="测试结果集", verbosity=2)
#     one_runner.run(one_suite)


