"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/1 13:37
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :py_unittest_assert_ways.py
@Software :PyCharm
********************************
"""
import unittest
import inspect


class Foo(object):
    """
    创建1个类
    """
    pass


class TestCase01(unittest.TestCase):
    """
    定义测试类,用于练习各种常用的断言方式
    """
    def test_case01(self):
        print("\n正在运行的测试用例:{}".format(inspect.stack()[0][3]))
        self.assertTrue("PYTHON".upper(), msg="测试是否为大写字母失败")

    def test_case02(self):
        print("\n正在运行的测试用例:{}".format(inspect.stack()[0][3]))
        obj = Foo()
        new_obj = obj
        self.assertIs(obj, new_obj,  msg="测试两个对象是否为同一个对象失败")

    def test_case03(self):
        print("\n正在运行的测试用例:{}".format(inspect.stack()[0][3]))
        obj = Foo()
        self.assertIsInstance(obj, Foo, msg="测试一个对象是否为某个类的实例失败")


if __name__ == "__main__":
    unittest.main()

