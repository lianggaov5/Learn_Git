# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/6/10 14:49
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :get_boss_job_result.py
@Software :PyCharm
********************************
"""
# boss自动化测试热门岗位一键获取
import requests
from lxml import etree

for page in range(1, 11):
    # 目标网站的地址
    url = "https://www.zhipin.com/c101010100-p100302/?query=%E6%9D%AD%E5%B7%9E&page={}&ka=page-{}".format(page, page)

    # 构造http请求头
    header = {
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)"
                          " Chrome/72.0.3626.121 Safari/537.36"
    }

    # 发送请求，获取页面内容
    response = requests.get(url=url, headers=header)

    # 获取页面内容（代码）
    html_str = response.text

    # 转换
    html = etree.HTML(html_str)

    # 提取目标数据（招聘岗位）
    # job_list = html.xpath('//*[@id="main"]/div/div[3]/ul/li')

    job_list = html.xpath('//div[@class="job-list"]/ul/li')
    for job in job_list:
        # 获取岗位名称
        job_name = job.xpath('.//div[@class="job-title"]/text()')
        # 获取薪资待遇
        salary = job.xpath('.//span[@class="red"]/text()')
        # 获取公司名称
        job_company = job.xpath('.//div[@class="company-text"]/h3/a/text()')
        # 格式一下数据
        # job_data = '岗位名称：{} 薪资待遇：{} 公司名称：{}'.format("".join(job_name), "".join(salary), "".join(job_company))
        job_data = '岗位名称：{} 薪资待遇：{} 公司名称：{}'.format(job_name[0], salary[0], job_company[0])
        # 将提取的数据写入文件
        with open("get_job_result.txt", "a", encoding="utf8") as file:
            file.write(job_data+"\n")
