"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/14 12:37
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :lemon_01_namedtuple.py
@Software :PyCharm
********************************
"""
# 命名元组
# 将元组封装成一个类，可以通过字段名（属性名）来访问元组中的值
from collections import namedtuple

# 1、定义一个类，创建一个类
# 方法一、传递属性名之间以空格间隔的字符串
# Love = namedtuple("Love", "name gender age love_into hobby motto")
# 方法二、传递属性名之间以英文逗号间隔的字符串
# Love = namedtuple("Love", "name，gender，age，love_into，hobby，motto")
# 方法三、
fields = ["name", "gender", "age", "love_into", "hobby", "motto"]
Love = namedtuple("Love", fields)
# 2、创建一个对象
# 方法一
# keyou = Love("可优", "男", 17, "lemon girl", "coding", "never stop learning")
# 方法二
one_person_value = ["可优", "男", 17, "lemon girl", "coding", "never stop learning"]
keyou = Love._make(one_person_value)
# 3、获取命名元组的值
# a.支持元组的所有操作，keyou就相当于元组，不过它比元组功能更强大
print(getattr(keyou, "age"))
print("{}".format(keyou.name))
print("{}".format(keyou[0]))
print("{}".format(keyou[3:5]))
# {'name': '可优', 'gender': '男', 'age': 17, 'love_into': 'lemon girl', 'hobby': 'coding', 'motto': 'never stop learning'}
print(dict(keyou._asdict()))
print(keyou._fields)  # ('name', 'gender', 'age', 'love_into', 'hobby', 'motto')
print(keyou._replace(age=12))  # 调用_replace创建了新的元组，命名元组不可修改
# 新建new Watch里面写id(keyou),Evaluate里id(keyou._replace(age=12))
# keyou.age = 1  # 会报错，命名元组不可修改
pass


