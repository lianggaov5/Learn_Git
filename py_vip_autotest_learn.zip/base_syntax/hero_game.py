"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/5 14:13
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :hero_game.py
@Software :PyCharm
********************************
"""


class Hero:

    def __init__(self, nickname, attack, blood):
        self.nickname = nickname
        self.attack = attack
        self.blood = blood

    def fight(self, hero):
        hero.blood = hero.blood - self.attack
        if hero.blood <= 0:
            print("{}死亡".format(hero.nickname))


if __name__ == "__main__":
    ya_se = Hero("亚瑟", 300, 300)
    hou_zi = Hero("猴子", 300, 300)
    ya_se.fight(hou_zi)
    # print(hou_zi.blood)
