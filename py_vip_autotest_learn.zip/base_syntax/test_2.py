# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/4/20 10:29
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :test_2.py
@Software :PyCharm
********************************
"""
# list_1 = [1, 2]
# list_2 = [3, 4]
# list_1.append(list_2)
# # list_1.extend(list_2)
# print(list_1)
# dict_1 = {"name": "gl", "gender": "male"}
# dict_1.clear()
# print(dict_1)

# num1 = ['293', '6234', '5552', '5896']
# num2 = ''.join(num1)
list_1 = [1, 2]
list_2 = [1, 2]
tuple_1 = (1, 2)
tuple_2 = (1, 2)
a = {"name": "gl"}
b = {"name": "gl"}

print(list_1 is list_2)
print(tuple_1 is tuple_2)
print(a is b)


