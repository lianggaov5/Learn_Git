# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/4/19 19:01
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :test1.py
@Software :PyCharm
********************************
"""


import requests


class Login:
    def __init__(self, url, param):
        self.url = url
        self.param = param

    def http_request(self, **kwargs):
        pass

login_url = "http://47.107.168.87:8080/futureloan/mvc/api/member/login"
param = {"mobilephone": "18688773467", "pwd": "123456"}


# # 发送一个get请求
# resp = requests.get(login_url, params=param)
# print("响应头："+resp.headers)
# print("响应报文："+resp.text)
# print("相应状态码"+resp.status_code)
# # 发送一个post请求
# resp = requests.post(login_url, params=param)
# print("响应头："+resp.headers)
# print("响应报文："+resp.text)
# print("相应状态码"+resp.status_code)







