"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/1 8:52
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :math_operation_test_case.py
@Software :PyCharm
********************************
"""

import unittest  # 先导入模块
from unittest单元测试.py_unittest_math_operation_01 import MathOperation    # 再导入自定义模块
import inspect


class TestDiv(unittest.TestCase):
    """
    测试两个数相除
    """
    file = "test_record.txt"

    def test_two_positive_div(self):
        """
        测试两个正数相除
        :return:
        """
        print("\nRunning Test Method:{}".format(inspect.stack()[0][3]))
        real_result = MathOperation(4, 2).div()
        expect_result = 2
        msg = "测试两个正数相除"
        with open("test_record.txt", "a", encoding="utf-8") as file:
            try:
                self.assertEqual(real_result, expect_result, msg="测试两个正数相除失败")
            except AssertionError as e:
                # print("写入异常信息到日志记录器")
                file.write("{},执行结果:{}\n具体异常信息:{}\n".format(msg, "fail", e))
                print("具体异常信息为{}".format(e))
                raise e
            else:
                file.write("{},执行结果:{}\n".format(msg, "pass"))

    def test_two_negative_div(self):
        """
        测试两个负数相除
        :return:
        """
        print("\nRunning Test Method:{}".format(inspect.stack()[0][3]))
        real_result = MathOperation(-4, -2).div()
        expect_result = -2
        msg = "测试两个负数相除"
        with open("test_record.txt", "a", encoding="utf-8") as file:
            try:
                self.assertEqual(real_result, expect_result, msg="测试两个负数相除失败")
            except AssertionError as e:
                # print("写入异常信息到日志记录器")
                file.write("{},执行结果:{}\n具体异常信息:{}\n".format(msg, "fail", e))
                print("具体异常信息为：{}".format(e))
                raise e
            else:
                file.write("{},执行结果:{}\n".format(msg, "pass"))

    def test_positive_negative_div(self):
        """
        测试一正一负相除
        :return:
        """
        print("\nRunning Test Method:{}".format(inspect.stack()[0][3]))
        real_result = MathOperation(5, -1).div()
        expect_result = -1
        msg = "测试一正一负相除"
        with open("test_record.txt", "a", encoding="utf-8") as file:
            try:
                self.assertEqual(real_result, expect_result, msg="测试一正一负相除失败")
            except AssertionError as e:
                print("具体异常信息为：{}".format(e))
                file.write("{},执行结果:{}\n具体异常信息:{}\n".format(msg, "fail", e))
                raise e
            else:
                file.write("{},执行结果:{}\n".format(msg, "pass"))

    if __name__ == "__main__":
        unittest.main()











