"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/1 10:17
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :test_01_register.py
@Software :PyCharm
********************************
"""


