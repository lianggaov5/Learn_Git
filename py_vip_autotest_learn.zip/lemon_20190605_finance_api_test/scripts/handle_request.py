# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/5/31 9:39
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :handle_request.py
@Software :PyCharm
********************************
"""
import requests
import json
from lemon_20190605_finance_api_test.scripts.handle_log import HandleLog

do_log = HandleLog().get_logger()


class HandleRequest:
    """
    处理请求
    """
    def __init__(self):
        # 使用Session会自动管理cookies
        # 创建一个session对象，赋值为HandleRequest对象的属性one_session
        self.one_session = requests.Session()

    def __call__(self, method, url, data=None, is_json=False, **kwargs):
        # 判断method传参时是否为小写，若不是，转换成小写
        method = method.lower()
        # 判断data是否为json格式字符串，若是，转换成字典，不是，抛出异常
        if isinstance(data, str):
            try:
                data = json.loads(data)
            except Exception as e:
                # 调用日志器的error方法记录异常信息
                do_log.error("将json转换成python类型时，出现异常：{}".format(e))
                # 若data是字符串，不是json格式，用eval函数转换
                data = eval(data)
        # 判断为何种请求方法
        if method == "get":
            res = self.one_session.get(url=url, params=data, **kwargs)
        elif method == "post":
            # 如果请求数据为json格式数据，json=data,如果请求数据为data表单格式传参，data=data
            if is_json:
                res = self.one_session.post(url=url, json=data, **kwargs)
            else:
                res = self.one_session.post(url=url, data=data, **kwargs)
        else:
            res = None
            # # 调用日志器的error方法记录异常信息
            do_log.error("不支持{}请求方法".format(method))
            print("不支持{}请求方法".format(method))
        return res

    def close(self):
        # 关闭会话
        self.one_session.close()   # 只是回收资源，并不会中断会话


do_request = HandleRequest()

if __name__ == '__main__':
    # 1.构造url
    register_url = "http://test.lemonban.com:8080/futureloan/mvc/api/member/register"
    login_url = "http://test.lemonban.com:8080/futureloan/mvc/api/member/login"
    recharge_url = "http://test.lemonban.com:8080/futureloan/mvc/api/member/recharge"

    # 2.创建请求参数
    register_params = {
        "mobilephone": "15556075397",
        "pwd": "123456",
        "regname": "gl"
    }

    login_params = {
        "mobilephone": "15556075397",
        "pwd": "123456",
    }

    recharge_params = {
        "mobilephone": "15556075397",
        "amount": 8888
    }

    # 3.向服务器发送请求

    send_request = HandleRequest()

    # register
    resister_res = send_request("post", register_url, register_params)
    # login
    login_res = send_request("Post", login_url, login_params)
    # recharge
    recharge_res = send_request("Post", recharge_url, recharge_params)
    # 关闭会话
    send_request.close()

