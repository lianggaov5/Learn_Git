# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/6/12 14:11
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :handle_user.py
@Software :PyCharm
********************************
"""
from lemon_20190605_finance_api_test.scripts.handle_mysql import HandleMysql
from lemon_20190605_finance_api_test.scripts.handle_request import HandleRequest
from lemon_20190605_finance_api_test.scripts.handle_config import do_config


def create_new_user(regname, pwd="Gl123456"):
    """
    创建一个用户
    :param regname:
    :param pwd:
    :return:
    """
    handle_mysql = HandleMysql()
    send_request = HandleRequest()
    url = do_config.get("project", "url")+"/member/register"
    sql = "select `Id` from `member` where `MobilePhone` = %s"

    while True:
        mobilephone = handle_mysql.create_not_existed_phone()
        data = {"mobilephone": mobilephone, "pwd": pwd, "regname": regname}
        send_request(method="post",
                     url=url,
                     data=data)
        result = handle_mysql(sql, args=(mobilephone,))
        if result:
            user_id = result["Id"]
            break
    user_dict = {
        regname: {
            "Id": user_id,
            "regname": regname,
            "mobilephone": mobilephone,
            "pwd": pwd
        }
    }
    handle_mysql.close()
    send_request.close()
    return user_dict


def generate_users_config():
    """
    生成三个用户信息
    :return:
    """
    user_data_dict = {}
    user_data_dict.update(create_new_user("admin_user"))
    user_data_dict.update(create_new_user("invest_user"))
    user_data_dict.update(create_new_user("borrow_user"))
    do_config.write_config(user_data_dict, "user_accounts.conf")


if __name__ == '__main__':
    # print(generate_users_config())
    # do_config.write_config(generate_users_config(), "user_accounts.conf")
    generate_users_config()
