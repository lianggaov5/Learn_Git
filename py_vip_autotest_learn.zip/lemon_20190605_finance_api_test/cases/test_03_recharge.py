"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/17 12:21
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :handle_excel.py
@Software :PyCharm
********************************
"""
import unittest
import inspect
import json

from lemon_20190605_finance_api_test.libs.ddt import ddt, data

from lemon_20190605_finance_api_test.scripts.handle_excel import HandleExcel
from lemon_20190605_finance_api_test.scripts.handle_config import do_config
from lemon_20190605_finance_api_test.scripts.handle_log import HandleLog
from lemon_20190605_finance_api_test.scripts.handle_request import HandleRequest
from lemon_20190605_finance_api_test.scripts.constants import TEST_DATA_FILE_PATH
from lemon_20190605_finance_api_test.scripts.handle_context import Context
from lemon_20190605_finance_api_test.scripts.handle_mysql import HandleMysql

do_log = HandleLog().get_logger()
@ddt
class TestRecharge(unittest.TestCase):
    """
    测试充值功能
    """

    do_excel = HandleExcel(TEST_DATA_FILE_PATH, "recharge")
    cases_list = do_excel.get_cases()  # 获取所有的用例，返回一个嵌套命名元组的列表

    @classmethod
    def setUpClass(cls):
        """
        重写父类的类方法，在实例方法执行之前会被调用一次
        在所有用例执行之前会被执行
        :return:
        """
        cls.send_request = HandleRequest()
        cls.handle_sql = HandleMysql()
        do_log.info("\n{:=^40s}".format("开始执行充值功能用例"))

    @classmethod
    def tearDownClass(cls):
        """
        重写父类的类方法
        所有用例执行之后，会被调用一次
        :return:
        """
        cls.send_request.close()
        cls.handle_sql.close()
        do_log.info("\n{:=^40s}\n".format("充值功能用例执行结束"))

    @data(*cases_list)   # 装饰实例方法
    def test_recharge(self, data_namedtuple):
        """
        测试充值功能
        :param data_namedtuple:
        :return:
        """
        print("\nRunning Test Method:{}".format(inspect.stack()[0][3]))
        do_log.info("\nRunning Test Method:{}".format(inspect.stack()[0][3]))

        run_success_msg = do_config("msg", "success_result")
        run_fail_msg = do_config("msg", "fail_result")

        new_url = do_config.get("project", "url") + data_namedtuple.url
        new_data = Context().recharge_parameter(data_namedtuple.datas)
        method = data_namedtuple.method

        check_sql = data_namedtuple.check_sql
        if check_sql:
            check_sql = Context.recharge_parameter(check_sql)
            # print(check_sql)
            mysql_data = self.handle_sql(check_sql)
            # decimal.Decimal类型的数据，需要转化成float类型
            amount_before_recharge = float(mysql_data["LeaveAmount"])
            # 提高精度,充值后实际金额
            amount_before_recharge = round(amount_before_recharge, 2)

        response = self.send_request(method=method,
                                     url=new_url,
                                     data=new_data)  # 接口不支持json格式，只支持form表单，is_json=False
        print(new_data)
        try:
            self.assertEqual(200, response.status_code,
                             msg="测试【{}】失败，请求状态码为【{}】"
                             .format(data_namedtuple.title, response.status_code))
        except AssertionError as e:  # 出现异常，后面代码不会执行
            do_log.error("{},执行结果:{}\n具体异常信息:{}\n".format(data_namedtuple.title, run_fail_msg, e))
            raise e

        code = response.json().get("code")

        print("expect_result:{}".format(data_namedtuple.expected))
        # print("real_result:{}".format(response.text))

        try:
            self.assertEqual(code, str(data_namedtuple.expected),
                             msg="测试{}失败".format(data_namedtuple.title))
            if check_sql:
                check_sql = Context.recharge_parameter(check_sql)
                mysql_data = self.handle_sql(check_sql)
                # decimal.Decimal类型的数据，需要转化成float类型
                amount_after_recharge = float(mysql_data["LeaveAmount"])
                # 提高精度
                amount_after_recharge = round(amount_after_recharge, 2)
                new_data = json.loads(new_data, encoding="utf8")
                recharge_amount = new_data.get("amount")
                # 逾期金额
                actual_amount = round(amount_before_recharge+recharge_amount, 2)
                self.assertEqual(actual_amount, amount_after_recharge,
                                 msg="数据库中充值的金额有误！！")

        except AssertionError as e:
            print("具体异常信息为{}".format(e))
            do_log.error("{},执行结果:{}\n具体异常信息:{}\n".format(data_namedtuple.title, run_fail_msg, e))
            self.do_excel.write_case(row=data_namedtuple.case_id+1,
                                     actual=response.text,
                                     result=run_fail_msg)
            raise e
        else:
            self.do_excel.write_case(row=data_namedtuple.case_id+1,
                                     actual=response.text,
                                     result=run_success_msg)


if __name__ == "__main__":
    unittest.main()

