# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/5/31 8:06
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :send_post_request.py
@Software :PyCharm
********************************
"""
import requests


# 1.构造url
url = "http://test.lemonban.com:8080/futureloan/mvc/api/member/register"
# 2.创建请求参数
params = {
    "mobilephone": "15556075395",
    "pwd": "123456",
    "regname": "gl"
}

headers = {
    "user-agent": "Mozilla/5.0 gl/0.0.1"
}

json_params = '{"mobilephone": "15556075395","pwd": "123456","regname": "gl"}'

# 3.向服务器发送get请求，params为查询字符串参数
# res = requests.post(url, params=params)

# 将参数放在请求体中，用data传参，将会使用x-www-form-urlencoded形式来传参，且会放在请求体中
# res = requests.post(url, data=params)

# json   application-json形式传参，根据接口文档来选择
res = requests.post(url, json=json_params, headers=headers)
print(res.status_code)
print(res.text)
print(res.json())
print(dict(res.headers))
print(res.cookies)


