"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/23 17:20
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :handle_config.py
@Software :PyCharm
********************************
"""
# 1.使用两种方式封装配置文件的相关操作
# 第一种参考上课讲的方式
# 第二种参考我在班级群里发的文件（lemon_05_parser_config_5.py）
# 方法一：
from configparser import ConfigParser



class HandleConfig(ConfigParser):
    """
    定义处理配置文件的类
    """
    def __init__(self):   # 对父类的构造方法进行拓展
        super().__init__()   # 重写或者拓展父类的构造方法，往往我们需要先调用父类的构造方法
        self.filename = "test_case.conf"
        self.read(self.filename, encoding="utf8")   # 读取配置文件

    def __call__(self, section="DEFAULT", option=None, is_eval=False, is_bool=False):
        """
        '对象()'这种形式，__call__方法会被调用
        :param section: 区域名
        :param option: 选项名
        :param is_eval: 为默认参数，是否进行eval函数转换，默认不转换
        :param is_bool: 选项所对应的值是否需要转化为bool类型，默认不转换
        :return:
        """

        if option is None:
            # 一个对象(区域名)    # 能够获取此区域下的所有选项，构造出来的一个字典
            # 一个对象()  # 返回DEFAULT默认区域下的所有选项，构造成的一个字典
            return dict(self[section])

        if isinstance(is_bool, bool):
            if is_bool:
                # 一个对象(区域名, 选项名, is_bool=True)  # 将获取到的数据使用getboolean()方法来获取
                return self.getboolean(section, option)
        else:
            raise ValueError("is_bool必须是bool类型")
        data = self.get(section, option)
        # 如果获取到的数据为数字类型的字符型，自动转化为Python中数字类型
        if data.isdigit():  # 判断是否为数字类型的字符串
            return int(data)
        try:
            return float(data)  # 如果为浮点类型的字符串，则直接转换
        except ValueError:
            pass
        if isinstance(is_eval, bool):   # 判断是否是某类型
            if is_eval:
                # 一个对象(区域名, 选项名, is_eval=True)  # 将获取到的数据使用eval函数进行转换
                return eval(data)
        else:
            raise ValueError("is_eval")  # 手动抛异常
        return data
# 还可增加json格式


do_config = HandleConfig()

if __name__ == '__main__':
    config = HandleConfig()
    # print(config())
    # print(config("excel"))
    # print(config("excel", "two_res"))
    # print(config("excel", "two_res", is_bool=True))
    # print(config("excel", "five_res", is_eval=True))
    # print(config("excel", "actual_col", is_bool=True))






