# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/5/31 7:25
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :send_get_request.py
@Software :PyCharm
********************************
"""
import requests


# 通过注册接口，先向服务器发送get请求

# 1.构造url
url = "http://test.lemonban.com:8080/futureloan/mvc/api/member/register"
# 2.创建请求参数
params = {
    "mobilephone": "15556075395",
    "pwd": "123456",
    "regname": "gl"
}
# 3.向服务器发送get请求，parmams为查询字符串参数
res = requests.get(url, params=params)  # 返回一个response对象(响应报文)
print(res.status_code)  # 响应状态码
print(res.text)  # 响应体   json格式数据
print(res.headers)  # 响应头
print(res.json())   # 将响应体json格式数据（字符串）转换成字典
print(res.cookies)  # 获取cookie信息   类似于python中字典类型，支持所有的字典操作
