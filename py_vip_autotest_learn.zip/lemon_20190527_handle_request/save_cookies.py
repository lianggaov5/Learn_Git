# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/5/31 8:36
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :save_cookies.py
@Software :PyCharm
********************************
"""
import requests

# 1.构造url
login_url = "http://test.lemonban.com:8080/futureloan/mvc/api/member/login"
recharge_url = "http://test.lemonban.com:8080/futureloan/mvc/api/member/recharge"

# 2.创建请求参数
login_params = {
    "mobilephone": "15556075395",
    "pwd": "123456",
    "regname": "gl"
}

recharge_params = {
    "mobilephone": "15556075395",
    "amount": 8888
}

headers = {
    "user-agent": "Mozilla/5.0 gl/0.0.1"
}
# 3.向服务器发送get请求，params为查询字符串参数
login_res = requests.post(login_url, data=login_params, headers=headers)
login_cookies = login_res.cookies

# 充值
recharge_res = requests.post(recharge_url, data=recharge_params, headers=headers, cookies=login_cookies)
