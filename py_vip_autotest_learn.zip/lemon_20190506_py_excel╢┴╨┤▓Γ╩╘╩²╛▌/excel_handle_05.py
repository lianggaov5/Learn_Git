"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/15 11:03
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :excel_handle_04.py
@Software :PyCharm
********************************
"""
# 将读取的数据进行封装
# 使用namedtuple
from openpyxl import load_workbook
from collections import namedtuple

file_name = "test_cases.xlsx"
# 1、打开excel文件(已存在)
wb = load_workbook(file_name)
# 2、定位表单
ws = wb["multiply"]
# 3、定位单元格cell
# 获取表头的信息
# 返回的是一个生成器
# tuple(ws.iter_rows(max_row=1))和ws["A1:G1"]一样
sheet_head_tuple = tuple(ws.iter_rows(max_row=1, values_only=True))[0]
print(list(sheet_head_tuple))

# 方法1
# 将获取的数据转换成字典
# 生成器就相当于生成数据的机器，需要for循环和next来触发
# 定义一个嵌套列表的字典列表来保存用例
cases_list = []
cases = namedtuple("cases", sheet_head_tuple)  # 创建一个类cases,并赋值给cases
for data in ws.iter_rows(min_row=2, max_row=5, values_only=True):
    # 方法1
    # cases_list.append(
    #     {
    #         sheet_head_tuple[0]: data[0],
    #         sheet_head_tuple[1]: data[1],
    #         sheet_head_tuple[2]: data[2],
    #         sheet_head_tuple[3]: data[3],
    #         sheet_head_tuple[4]: data[4],
    #         sheet_head_tuple[5]: data[5],
    #         sheet_head_tuple[6]: data[6],
    #     }  # 表头信息，是手动书写的，这种做法好不好？为什么不好？ 拓展性比较差
    # )
    # 方法2 使用zip函数
    # cases_list.append(
    #     dict(zip(sheet_head_tuple, data))
    #   zip函数将两个序列的元素一一对应,组合成一个元组或一个字典，可以dict,list
    # 返回一个zip对象(生成器)、map函数、
    # )
    # list(zip(sheet_head_tuple, data))  # 嵌套元组的列表
    # tuple(zip(sheet_head_tuple, data))  # 嵌套元组的元组
    # 方法3 使用namedtuple
    cases_list.append(cases(*data))    # *data 元组拆包
print("{}".format(cases_list))


pass

