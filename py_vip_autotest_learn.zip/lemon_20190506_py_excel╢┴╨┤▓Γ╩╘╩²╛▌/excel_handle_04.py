"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/15 11:03
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :excel_handle_04.py
@Software :PyCharm
********************************
"""
# 痛点：如何将执行的用例结果写入到Excel
from openpyxl import load_workbook

file_name = "test_cases.xlsx"
# 1、打开excel文件(已存在)
wb = load_workbook(file_name)
# 2、定位表单
ws = wb["multiply"]
# 3、定位单元格cell, 根据行列坐标来定位再赋值
# 向excel中写入数据，或修改excel中数据
# 方法1
ws.cell(7, 1).value = 6
# 方法2
ws.cell(7, 2, value="零和负数相乘")
# 方法3
# 添加1行内容
row_data = ((7, "零和正数相乘", 0, 5, 0, None, None),
            (8, "零和负数相乘", 0, 7, 0, None, None),)
# 可以使用append方法来添加一行的数据
for row in row_data:
    ws.append(row)  # 可以传任何一个序列类型
# 修改excel之后，保存excel文件，保存在当前excel中，修改时excel文件要关闭
wb.save(file_name)

