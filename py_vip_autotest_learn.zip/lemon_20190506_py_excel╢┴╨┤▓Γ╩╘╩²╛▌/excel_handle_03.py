"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/6 21:11
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :excel_handle_01.py
@Software :PyCharm
********************************
"""
# 从Excel中读取的列表、字典、元组等python数据类型
from openpyxl import load_workbook  # 可以对已存在的excel文件进行处理(不存在报错)
from openpyxl import workbook  # 可以新建excel文件

# 使用load_workbook来实现excel读写
# 1、打开excel文件(已存在)
wb = load_workbook("test_cases.xlsx")

# 方法一：
ws = wb['multiply']   # ws 为Worksheet对象（相当于excel的一个表单）
# 方法二：
# ws = wb,actice  # 获取第一个表单

# 3、定位单元格cell
# sheets = ws["A2:G6"]   # 返回嵌套元组的元组，内层元组是由每一行的每一个单元格cell对象组成
# for row in sheets:
#     for column in row:
#         data = column.value
#         print("值为:{},类型为：{}\n".format(data, type(data)))
# pass
# 痛点：如何将非数字类型，转换成python中原本的类型
# 使用eval函数来处理，是最好的方法，也可以使用正则表达式处理，但需要掌握正则相关内容
# excel中的数字类型，读取到python中之后，也为数字类型（int float bool等）
# excel中的非数字类型，读取到python中之后，都会被当作字符串
# 使用eval函数将excel中的非数字类型数据转换成python原本可以识别的数据类型
# 在excel中保存Python中的数据类型时，一定要满足它的语法规范
c6_value = ws.cell(6, 2).value
c6_tuple = eval(c6_value)
print("{},{}".format(c6_tuple, type(c6_tuple)))

# eval("a")  # 开发过程中不推荐使用
# 第一个参数必须是字符串，且符合Python语法规范
# 可以是python中的数据类型，也可以是表达式（算数运算、逻辑运算符）
# 尽量不要这样用，可能用户会传入一些非法代码，python执行之后，有很大危害
# one_str = input("请输入：")
# print(eval(one_str))
pass
