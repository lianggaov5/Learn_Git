"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/6 21:11
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :excel_handle_01.py
@Software :PyCharm
********************************
"""
from openpyxl import load_workbook

wb = load_workbook("test_cases.xlsx")
ws = wb['multiply']
# data_list = []
# for row_index in range(ws.min_row+1, ws.max_row+1):
#     data_list_temp = []
#     for column_index in range(ws.min_column+1, ws.max_column+1):
#         data = ws.cell(row_index, column_index).value
#         data_list_temp.append(data)
#     data_list.append(data_list_temp)
# print(data_list)

# for row_tuple_value in ws.iter_rows(min_row=2, values_only=True):
#     for one_cell_value in row_tuple_value:
#         data = one_cell_value
#         print(data)
# pass
# sheets = ws["A2:G5"]
# for row in sheets:
#     for column in row:
#         data = column.value
#         print(data)
# pass
