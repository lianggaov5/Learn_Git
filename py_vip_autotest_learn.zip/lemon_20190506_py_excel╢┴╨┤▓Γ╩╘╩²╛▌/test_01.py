"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/16 17:33
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :test_01.py
@Software :PyCharm
********************************
"""
from openpyxl import load_workbook
from collections import namedtuple

file_name = "div_cases.xlsx"
sheet_name = "divide"
wb = load_workbook(file_name)
ws = wb[sheet_name]
sheet_head_tuple = tuple(ws.iter_rows(min_row=1, values_only=True))[0]
data_list = []
cases = namedtuple("cases", sheet_head_tuple)
# for data in ws.iter_rows(min_row=2, values_only=True):
#     data_list.append(dict(zip(sheet_head_tuple, data)))
# print(data_list)
for data in ws.iter_rows(min_row=2, values_only=True):
    data_list.append(cases(*data))
print(data_list)


