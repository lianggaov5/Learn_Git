"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/6 21:11
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :excel_handle_01.py
@Software :PyCharm
********************************
"""
from openpyxl import load_workbook
from openpyxl import workbook  # 可以新建excel文件

# 使用load_workbook来实现excel读写
# 1、打开excel文件
wb = load_workbook("test_cases.xlsx")  # 返回一个Worksheet对象（相当于整个excel文件）
# 代码新建一个excel文件
# wb = workbook.Workbook()
# wb.create_sheet(title="multiply", index=0)    # index=0代表为第1个表单命名

# 2、定位表单
# 方法一：
ws = wb['multiply']   # ws 为Worksheet对象（相当于excel的一个表单）
# 方法二：
# ws = wb.actice # 获取第一个表单

# 3、定位单元格cell，读取值
# 行列坐标都必须数字 对应关系：A代表第1列  B代表第2列 C代表第3列 D代表第4列
cell_value = ws.cell(2, 2)  # one_cell为Cell对象（相当于一个表单中的单元格）
print("{}".format(cell_value))

# 4、定位单元格cell，写入值
ws.cell(7, 2).value = "测试插入数据"
ws.cell(8, 2, "test")   # 写入值test
C6 = ws.cell(7, 2).value  # 写入之后再读取
print("{}".format(C6))

# 5、写入值之后要保存文件
wb.save("test_cases.xlsx")  # 保存excel文件

# 操作完毕之后，关闭文件
wb.close()
