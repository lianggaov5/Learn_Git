"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/1 8:52
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :math_operation_test_case.py
@Software :PyCharm
********************************
"""
# 6.完成如下程序
# a.使用Excel来记录两数相除的测试用例（手动写入数据）
# b.使用openpyxl将所有用例数据读取出来
# c.分别使用多种方法来封装测试用例数据（嵌套字典的列表和嵌套命名元组的列表）
from openpyxl import load_workbook
from collections import namedtuple
file_name = "div_cases.xlsx"
# 1.打开excel文件
wb = load_workbook(file_name)
# 2.定位表单
ws = wb["divide"]
# 3.定位单元格cell,将所有用例数据读取出来
for data in ws.iter_rows(min_row=1, values_only=True):
    print(data)
# 获取第一行表头的信息
sheet_head_tuple = tuple(ws.iter_rows(max_row=1, values_only=True))[0]
cases_list1 = []
# 1)将用例数据封装成嵌套字典的列表
for data in ws.iter_rows(min_row=2, values_only=True):
    cases_list1.append(
        dict(zip(sheet_head_tuple, data))
    )
print(cases_list1)
# 2)将用例数据封装成嵌套命名元组的列表
cases_list2 = []
cases = namedtuple("cases", sheet_head_tuple, rename=True)  # 创建一个命名元组的类cases，并赋值给cases
for data in ws.iter_rows(min_row=2, values_only=True):
    cases_list2.append(cases(*data))  # cases(*data)：创建一个对象即命名元组，*data表示元组拆包
print(cases_list2)
pass
