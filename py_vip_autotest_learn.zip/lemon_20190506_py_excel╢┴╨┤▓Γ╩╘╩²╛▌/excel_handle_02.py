"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/6 21:11
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :excel_handle_01.py
@Software :PyCharm
********************************
"""
# 痛点：通过Worksheet中的cell方法，每次调用只能处理一个单元格的数据
# 如何批量处理一个表单中的数据呢？

from openpyxl import load_workbook  # 可以对已存在的excel文件进行处理(不存在报错)

wb = load_workbook("test_cases.xlsx")

ws = wb['multiply']   # ws 为Worksheet对象（相当于excel的一个表单）


# one_cell = ws.cell(row=2, column=2)  # one_cell为Cell对象（相当于一个表单中的单元格）
# print(one_cell.value)

# 方法二：循环读值
# Worksheet对象有如下重要的属性：
# max_row：单元格最大行
# min_row：单元格最小行
# max_column：单元格最大列
# min_column：单元格最小列
# Worksheet对象中有以下重要的方法：
# iter_rows：返回一个生成器，是返回每一行的数据构成的元组
# iter_columns：返回一个生成器，是返回每一列的数据构成的元组

# for row_index in range(ws.min_row+1, ws.max_row+1):
#     for column_index in range(ws.min_column, ws.max_column):
#         data = ws.cell(row=row_index, column=column_index).value
#         print("值为:{},类型为：{}".format(data, type(data)))

# excel中如果获取的是数字（int、float），那么读取的数据也是数字类型，所有的非数字，读取的都是字符串类型
# eval() 可以把数据转成python原本可以识别的数据类型

# 方法三：
# for row_tuple in ws.iter_rows(min_row=2):  # 每遍历一次，会将某一行的所有单元格对象（Cell对象）组成一个元组返回
#     # print(row_tuple)
#     for one_cell in row_tuple:
#         data = one_cell.value
#         print("值为:{},类型为：{}".format(data, type(data)))

for row_tuple_value in ws.iter_rows(min_row=2, values_only=True):    # 推荐使用
    # 每遍历一次，会将某一行的所有单元格（Cell对象）的值组成一个元组返回
    for one_cell_value in row_tuple_value:
        data = one_cell_value
        print("值为:{},类型为：{}\n".format(data, type(data)))
# 读数据不需要关闭，也不需要保存excel

# 方法四：指定需要处理的所有单元格
# sheets = ws["A2:G5"]   # 返回嵌套元组的元组，内层元组是由每一行的每一个单元格cell对象组成
# for row in sheets:
#     for column in row:
#         data = column.value
#         print("值为:{},类型为：{}\n".format(data, type(data)))

