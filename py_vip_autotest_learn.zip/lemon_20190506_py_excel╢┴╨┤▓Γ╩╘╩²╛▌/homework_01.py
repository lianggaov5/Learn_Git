"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/7 13:59
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :homework_01.py
@Software :PyCharm
********************************
"""
from openpyxl import load_workbook


class DoExcel:
    # 把公有属性封装到构造方法中
    def __init__(self, file_name, sheet_name):
        self.file_name = file_name
        self.sheet_name = sheet_name

    def read_data(self):
        wb = load_workbook(self.file_name)
        ws = wb[self.sheet_name]
        all_data = []  # 大列表，保存所有的数据
        for row in range(1, ws.max_row+1):
            sub_list = []  # 小列表，保存每行数据
            for column in range(1, ws.max_column+1):
                sub_list.append(ws.cell(row, column).value)
            all_data.append(sub_list)

        print("{}".format(all_data))
        wb.close()
        return all_data

    def write_data(self, row, column, new_value):
        wb = load_workbook(self.file_name)
        ws = wb[self.sheet_name]
        ws.cell(row, column).value = new_value
        wb.save(self.file_name)
        wb.close()


if __name__ == "__main__":
    de = DoExcel("test_cases.xlsx", "multiply")
    de.write_data(7, 3, 2)
    de.read_data()






