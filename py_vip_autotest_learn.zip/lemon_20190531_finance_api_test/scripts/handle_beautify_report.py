"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/5 22:22
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :run_test.py
@Software :PyCharm
********************************
"""
import unittest
from datetime import datetime
import os

from lemon_20190531_finance_api_test.libs.HTMLTestRunnerNew import HTMLTestRunner

from lemon_20190531_finance_api_test.cases import test_case_register as module01


from lemon_20190531_finance_api_test.scripts.handle_config import do_config

from lemon_20190531_finance_api_test.scripts.constants import REPORTS_DIR
# from unittest单元测试 import py_unittest_assert_ways as module02

# 1. 创建一个加载器，加载所有的模块
one_loader = unittest.TestLoader()
test_module_tuple = (one_loader.loadTestsFromModule(module01)

                     )

# 2. 创建测试套件
# 在创建测试套件时，将所有的测试模块所构成的元组传给TestSuite类
one_suite = unittest.TestSuite(tests=test_module_tuple)  # 调用父类的__init__方法
TEST_REPORTS_FILE_PATH = os.path.join(REPORTS_DIR, do_config.get("report", "report_html_name"))
report_html_full_name = TEST_REPORTS_FILE_PATH+"_"+datetime.strftime(datetime.now(), "%Y%m%d%H%M%S")+".html"
# 3. 执行用例
with open(report_html_full_name, mode="wb") as save_to_file:
    one_runner = HTMLTestRunner(stream=save_to_file,
                                title=do_config("report", "title"),
                                verbosity=do_config("report", "verbosity", is_eval=True),
                                description=do_config("report", "description"),
                                tester=do_config("report", "tester"),
                                )
    one_runner.run(one_suite)



