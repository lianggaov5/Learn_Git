# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/5/31 13:13
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :handle_mysql.py
@Software :PyCharm
********************************
"""
# 需要使用第三方库pymysql
import random
import pymysql
import re
from lemon_20190531_finance_api_test.scripts.handle_config import do_config


class HandleMysql:
    """
    处理数据库
    """
    not_existed_tel_pattern = re.compile(r"\$\{not_existed_phone\}")
    not_existed_regname_pattern = re.compile(r"\$\{not_existed_regname\}")
    sql = "select MobilePhone from member where MobilePhone = %s"

    def __init__(self):
        self.connect = pymysql.connect(
            host=do_config("database", "host"),
            port=do_config("database", "port", is_eval=True),
            user=do_config("database", "user"),
            password=do_config("database", "password"),
            db=do_config("database", "db"),
            charset=do_config("database", "charset"),
            cursorclass=pymysql.cursors.DictCursor
         )
        self.cursor = self.connect.cursor()

    def __call__(self, sql, args=None, is_more=False):
        """
         获取查询到的数据
        :param sql:sql语句
        :param args:sql语句的参数，传入序列类型
        :param is_more: True为多个，False为单个
        :return:返回字典类型或嵌套字典的列表
        """
        self.cursor.execute(sql, args)
        self.connect.commit()
        if is_more:
            # 获取多条记录
            result = self.cursor.fetchall()
        else:
            # 获取单条记录
            result = self.cursor.fetchone()
        return result

    def close(self):
        """
        关闭连接
        :return:
        """
        self.cursor.close()
        self.connect.close()

    @staticmethod
    def create_phone():
        """
        随机创建手机号
        :return:
        """
        top_three = ["131", "136", "138", "155", "183", "188"]
        last_eight = str(random.randint(10000000, 99999999))
        return random.choice(top_three) + last_eight

    def is_existed_tel(self, phone):
        """
        判断手机号是否在数据库中存在
        :param phone:
        :return:
        """
        sql = 'select id from member where MobilePhone=%s;'

        # 手机号在数据库中存在，返回True，否则返回False
        if self(sql, args=(phone,)):
            return True
        else:
            return False

    def not_existed_tel_replace(self, data):
        """
        对未注册的手机号，进行参数化
        :param data:
        :return:
        """
        # 创建随机手机号
        random_phone = self.create_phone()

        # 如果手机号在数据库中存在，则再次随机创建
        while self.is_existed_tel(random_phone):
            random_phone = self.create_phone()

        while not self.is_existed_tel(random_phone):

            if re.search(self.not_existed_tel_pattern, data):
                # sub中第一个参数为pattern模式对象,第二个参数为需要替换的值,第三个参数为原始字符串
                data = re.sub(self.not_existed_tel_pattern, random_phone, data)

            if re.search(self.not_existed_regname_pattern, data):
                data = re.sub(self.not_existed_regname_pattern, "gl", data)

            break

        return data


do_mysql = HandleMysql()


if __name__ == '__main__':
    data = '{"mobilephone":"${not_existed_phone}","pwd":"123456","regname":"${not_existed_regname}"}'
    do_mysql = HandleMysql()
    res = do_mysql.not_existed_tel_replace(data)
    pass

    # sql1 = "select * from member limit 0, 10;"
    # sql2 = "select * from member where LeaveAmount > %s limit 0, %s;"
    # do_mysql = HandleMysql()
    # res1 = do_mysql(sql=sql1)  # 获取一条记录
    # res2 = do_mysql(sql=sql2, args=(1000, 10))  # 获取一条记录（sql语句中带参数）
    # res3 = do_mysql(sql=sql1, is_more=True)  # 获取多条记录
    # res4 = do_mysql(sql=sql2, args=(1000,), is_more=True)  # 获取多条记录（sql语句中带参数）
    # print(float(res1["LeaveAmount"]))
    # print(res1)
    # print(res2)
    # do_mysql.close()
