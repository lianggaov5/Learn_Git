"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/17 12:21
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :handle_excel.py
@Software :PyCharm
********************************
"""
# 如何来封装一些操作
# 1.明确需求（读取所有的测试用例、读取一条测试用例、写入结果）
# 2.把一些写死的数据提取出来，往往当作属性
# 3.如果其它实例方法中需要调用实例方法中的变量，那么需要将其定义为属性


import unittest
import inspect
import json

from lemon_20190531_finance_api_test.libs.ddt import ddt, data

from lemon_20190531_finance_api_test.scripts.handle_excel import HandleExcel
from lemon_20190531_finance_api_test.scripts.handle_config import do_config
from lemon_20190531_finance_api_test.scripts.handle_log import do_log
from lemon_20190531_finance_api_test.scripts.handle_request import do_request
from lemon_20190531_finance_api_test.scripts.constants import TEST_DATA_FILE_PATH
from lemon_20190531_finance_api_test.scripts.handle_mysql import do_mysql


@ddt
class TestRegister(unittest.TestCase):
    """
    注册
    """
    do_excel = HandleExcel(TEST_DATA_FILE_PATH, "login")
    login_cases_list = do_excel.get_cases()  # 获取所有的用例，返回一个嵌套命名元组的列表

    @classmethod
    def setUpClass(cls):
        """
        重写父类的类方法，在实例方法执行之前会被调用一次
        在所有用例执行之前会被执行
        :return:
        """
        do_log.info("\n{:=^40s}".format("开始执行用例"))

    @classmethod
    def tearDownClass(cls):
        """
        重写父类的类方法
        所有用例执行之后，会被调用一次
        :return:
        """
        do_log.info("\n{:=^40s}\n".format("用例执行结束"))
        do_request.close()

    @data(*login_cases_list)   # 装饰实例方法
    def test_future_register(self, data_namedtuple):
        # 查看当前运行的实例方法名称，用例根据实例方法名按照ascii码顺序运行
        # 单元测试中实例方法执行的时候，如果抛出异常，那么这个实例方法会终止执行，
        # 有for循环的话，代码一直执行，直到抛出异常结束
        print("\nRunning Test Method:{}".format(inspect.stack()[0][3]))
        do_log.info("\nRunning Test Method:{}".format(inspect.stack()[0][3]))
        case_id = data_namedtuple.case_id
        msg = data_namedtuple.title

        url = do_config.get("project", "url") + data_namedtuple.url
        data = data_namedtuple.data
        method = data_namedtuple.method

        expect_result = data_namedtuple.expected

        real_result = do_request(method, url, data).text

        run_success_msg = do_config("msg", "success_result")
        run_fail_msg = do_config("msg", "fail_result")
        print("expect_result:{}".format(expect_result))
        print("real_result:{}".format(real_result))

        try:
            self.assertEqual(real_result, expect_result, msg="测试{}登陆失败".format(msg))
        except AssertionError as e:
            print("具体异常信息为{}".format(e))
            do_log.error("{},执行结果:{}\n具体异常信息:{}\n".format(msg, run_fail_msg, e))
            self.do_excel.write_case(row=case_id+1, actual=real_result, result=run_fail_msg)
            raise e
        else:
            self.do_excel.write_case(row=case_id + 1, actual=real_result, result=run_success_msg)


if __name__ == "__main__":
    unittest.main()

