# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/5/31 13:13
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :handle_mysql.py
@Software :PyCharm
********************************
"""
# 需要使用第三方库pymysql
import random
import pymysql
from lemon_20190529_handle_pymysql.handle_config import do_config


class HandleMysql:
    """
    处理数据库
    """
    def __init__(self):
        self.connect = pymysql.connect(
            host=do_config("database", "host"),
            port=do_config("database", "port", is_eval=True),
            user=do_config("database", "user"),
            password=do_config("database", "password"),
            db=do_config("database", "db"),
            charset=do_config("database", "charset"),
            cursorclass=pymysql.cursors.DictCursor
         )
        self.cursor = self.connect.cursor()

    def __call__(self, sql, args=None, is_more=False):
        """
         获取查询到的数据
        :param sql:sql语句
        :param args:sql语句的参数，传入序列类型
        :param is_more: True为多个，False为单个
        :return:返回字典类型或嵌套字典的列表
        """
        self.cursor.execute(sql, args)
        self.connect.commit()
        if is_more:
            # 获取多条记录
            result = self.cursor.fetchall()
        else:
            # 获取单条记录
            result = self.cursor.fetchone()
        return result

    def close(self):
        """
        关闭连接
        :return:
        """
        self.cursor.close()
        self.connect.close()

    @staticmethod
    def create_phone():
        top_three = ["130", "131", "132", "133", "134", "135", "136", "137", "138", "139",
                     "145", "147", "149",
                     "150", "151", "152", "153", "155", "156", "157", "158", "159",
                     "180", "181", "182", "183", "185", "186", "187", "188", "189"]
        last_eight = str(random.randint(10000000, 99999999))
        return random.choice(top_three) + last_eight


do_mysql = HandleMysql()


if __name__ == '__main__':
    sql1 = "select * from member limit 0, 10;"
    sql2 = "select * from member where LeaveAmount > %s limit 0, %s;"
    do_mysql = HandleMysql()
    res1 = do_mysql(sql=sql1)  # 获取一条记录
    res2 = do_mysql(sql=sql2, args=(1000, 10))  # 获取一条记录（sql语句中带参数）
    # res3 = do_mysql(sql=sql1, is_more=True)  # 获取多条记录
    # res4 = do_mysql(sql=sql2, args=(1000,), is_more=True)  # 获取多条记录（sql语句中带参数）
    print(float(res1["LeaveAmount"]))
    print(res1)
    print(res2)
    do_mysql.close()
