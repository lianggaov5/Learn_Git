# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/5/31 21:27
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :handle_re_match.py
@Software :PyCharm
********************************
"""
import re

target_str = '{"mobilephone": "${not_existed_tel}","pwd": "123456", "regname": "gl"}'

# 1.将正则字符串编译成Pattern对象
not_existed_tel_pattern = re.compile(r"\$\{not_existed_tel\}")
not_existed_regname_pattern = re.compile(r"\$\{regname\}")


def not_existed_tel_replace(data):

    if re.search(not_existed_tel_pattern, data):
        # sub中第一个参数为pattern模式对象,第二个参数为需要替换的值,第三个参数为原始字符串
        data = re.sub(not_existed_tel_pattern, "18911117777", data)

    if re.search(not_existed_regname_pattern, data):
        data = re.sub(not_existed_regname_pattern, "gl", data)

    return data


if __name__ == '__main__':
    target_str1 = '{"mobilephone": "${not_existed_tel}","pwd": "123456", "regname": "${not_existed_tel}"}'
    target_str2 = '{"mobilephone": "${not_existed_tel}","pwd": "123456", "regname": "${regname}"}'
    target_str3 = '{"mobilephone": "","pwd": "123456", "regname": "gl"}'
    target_str4 = '{"mobilephone": "13155186317","pwd": "123456"}'
    print(not_existed_tel_replace(target_str1))
    print(not_existed_tel_replace(target_str2))
    print(not_existed_tel_replace(target_str3))
    print(not_existed_tel_replace(target_str4))
