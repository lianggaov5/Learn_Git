# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/5/31 22:43
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :get_boss_job_result.py
@Software :PyCharm
********************************
"""
import random


def create_phone2():

    # 第二位数字
    second = [3, 4, 5, 7, 8][random.randint(0, 4)]
    # 第三位数字
    third = {3: random.randint(0, 9),
             4: [5, 7, 9][random.randint(0, 2)],
             5: [i for i in range(10) if i != 4][random.randint(0, 8)],
             7: [i for i in range(10) if i not in [4, 9]][random.randint(0, 7)],
             8: random.randint(0, 9), }[second]
    # 最后八位数字
    last_eight = random.randint(9999999, 100000000)
    # 拼接手机号
    return "1{}{}{}".format(second, third, last_eight)
# 生成手机号
# ^(13[0-9]|14[5|7]|15[0|1|2|3|5|6|7|8|9]|18[0|1|2|3|5|6|7|8|9])\d{8}$


def create_phone():
    top_three = ["130", "131", "132", "133", "134", "135", "136", "137", "138", "139",
                 "145", "147", "149",
                 "150", "151", "152", "153", "155", "156", "157", "158", "159",
                 "180", "181", "182", "183", "185", "186", "187", "188", "189"]
    last_eight = str(random.randint(10000000, 99999999))
    return random.choice(top_three) + last_eight


phone = create_phone()
phone2 = create_phone2()
print(phone)
print(phone2)
