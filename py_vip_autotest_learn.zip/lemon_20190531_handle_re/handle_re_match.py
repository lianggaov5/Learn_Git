# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/5/31 21:27
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :handle_re_match.py
@Software :PyCharm
********************************
"""
import re

target_str = '{"mobilephone": "${not_existed_tel}","pwd": "123456", "regname": "gl"}'

# 1.将正则字符串编译成Pattern对象
pattern = re.compile(r".*\$\{not_existed_tel\}")

# 2.使用Pattern对象去匹配文本
# 如果未匹配上，则返回None,如果能匹配上返回match
# match_obj = re.match(pattern, target_str)

# 如果未匹配上，则返回None,如果能匹配上,返回match
match_obj = re.search(pattern, target_str)
# new_str中第一个参数为pattern模式对象,第二个参数为需要替换的值,第三个参数为原始字符串
new_str = re.sub(pattern, "18911117777", target_str)
