# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/4/22 12:56
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :py_class_tool_box.py
@Software :PyCharm
********************************
"""
"""
需求：
编写一个工具箱类，需要有工具的名称、功能描述、价格，
能够添加工具、删除工具、查看工具，
并且能获取工具箱中工具的总数。
"""


class ToolBox:

    def __init__(self, name, price, func):
        self.name = name
        self.price = price
        self.func = func

    def add_tool(self, tool):
        for item in tool:
            if item["名称"] != self.name:
                tool.append({"名称": self.name, "价格": self.price, "功能": self.func})
            else:
                print("添加的工具已存在！")
        return tool

    def delete_tool(self, tool):
        for item in tool:
            if item == {"名称": self.name, "价格": self.price, "功能": self.func}:
                tool.remove(item)
            else:
                print("删除的工具不存在！")
        return tool

    def describe_tool(self, tool):
        for item in tool:
            if item['名称'] == self.name:
                print({"名称": self.name, "价格": self.price, "功能": self.func})
            else:
                print("查找的工具不存在！")

    @staticmethod
    def get_tool_num(tool):
        print("工具箱中工具的总数：{}".format(len(tool)))


if __name__ == "__main__":
    tool_box = []
    tb = ToolBox("手枪", "1000", "防身")
    tb.add_tool(tool_box)
    tb.describe_tool(tool_box)
    # tb.delete_tool(tool_box)
    # tb.describe_tool(tool_box)
    tb.get_tool_num(tool_box)


