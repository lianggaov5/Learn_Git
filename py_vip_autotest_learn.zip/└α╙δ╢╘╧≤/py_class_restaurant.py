# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/4/20 10:48
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :py_class_restaurant.py
@Software :PyCharm
********************************
"""


class Restaurant:

    def __init__(self, restaurant_name, cooking_type):
        self.restaurant_name = restaurant_name
        self.cooking_type = cooking_type

    def describe_restaurant(self):
        print("本店店名："+self.restaurant_name)
        items = ""
        for item in self.cooking_type:
            items += item
            items += ","
        print("本店特色美食："+items)

    def open_restaurant(self):
        print(self.restaurant_name+"正在火爆营业，欢迎大家前来惠顾！")


if __name__ == "__main__":
    name = "百年老字号，吉祥好运店"
    cooking = ("红烧肉", "黄山臭桂鱼", "清香乌冬面", "西红柿土豆排骨汤")
    restaurant = Restaurant(name, cooking)
    restaurant.describe_restaurant()
    restaurant.open_restaurant()
