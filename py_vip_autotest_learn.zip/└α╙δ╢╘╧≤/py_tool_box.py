# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/4/20 11:35
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :py_tool_box.py
@Software :PyCharm
********************************
"""


class ToolBox:

    def __init__(self, name, price, func):
        self.name = name
        self.price = price
        self.func = func

    def add_tool(self, file1):
        """
        增加工具
        :param file1:
        :return:
        """
        with open(file1, "a+", encoding="utf-8") as file2:
            items = ""
            for item in (self.name, self.price, self.func):
                items += str(item)
                items += ","
            file2.write(items.rstrip(",") + "\n")

    def delete_tool(self, file1):
        """
        删除工具
        :param file1:
        :return:
        """
        with open(file1, "r", encoding="utf-8") as file2:
            lines = file2.readlines()
        with open(file1, "w", encoding="utf-8") as file2:
            for line in lines:
                if self.name not in line:
                    file2.write(line)

    def change_tool(self, file1, name, price, func):
        """
        修改工具
        :param file1:
        :param name:
        :param price:
        :param func:
        :return:
        """
        with open(file1, "r", encoding="utf-8") as file2:
            lines = file2.readlines()
        with open(file1, "w", encoding="utf-8") as file2:
            for line in lines:
                if self.name in line:
                    line = name+","+str(price)+","+func+"\n"
                    file2.write(line)
                    continue
                file2.write(line)

    def search_tool(self):
        """
        查找工具
        :return:
        """
        print(self.name+"价格："+str(self.price)+",功能："+self.func)

    @staticmethod
    def search_all_tool(file1):
        """
        查找所有的工具
        :param file1:
        :return:
        """
        with open(file1, "r", encoding="utf-8") as file2:
            lines = file2.readlines()
            for line in lines:
                print(line, end="")

    @staticmethod
    def get_tool_num(file1):
        """
        获得工具的数量
        :param file1:
        :return:
        """
        with open(file1, "r", encoding="utf-8") as file2:
            lines = file2.readlines()
            count = 0
            for line in lines:
                if "\n" in line:
                    count += 1
            print("工具的数量:{}".format(count-1))


if __name__ == "__main__":
    file = "1.txt"
    with open(file, "w+", encoding="utf-8") as txt:
        txt.write("工具,价格,功能\n")
    tool = ToolBox("斧头", 500, "砍柴")
    tool2 = ToolBox("气枪", 2000, "打野")
    tool3 = ToolBox("气球", 100, "装饰")
    tool.add_tool(file)         # 增加工具
    tool2.add_tool(file)
    tool3.add_tool(file)
    tool.search_tool()          # 查看单个工具
    tool2.search_tool()
    tool3.search_tool()
    # tool.delete_tool(file)      # 删除工具
    # tool2.delete_tool(file)     # 删除工具
    tool.change_tool(file, "手枪", 1500, "防身")  # 修改工具
    print("*"*50)
    tool.search_all_tool(file)  # 查看所有工具
    tool.get_tool_num(file)




