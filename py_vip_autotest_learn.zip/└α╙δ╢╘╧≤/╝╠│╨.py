# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/4/24 17:41
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :继承.py
@Software :PyCharm
********************************
"""


class Animal:  # python3中默认继承object类
    """
    define Animal class
    """
    def __init__(self, name, age, color):
        """

        :param name:
        :param age:
        :param color:
        """
        self.name, self.age, self.color = name, age, color

    def eat(self):
        print("{}吃东西".format(self.name))

    def drink(self):
        print("{}喝水".format(self.name))

    def run(self):
        print("{}会跑".format(self.name))

    def sleep(self):
        print("{}睡觉".format(self.name))


class Dog(Animal):

    def bark(self):
        print("{}会汪汪汪".format(self.name))


class Cat(Animal):

    def catch(self):
        print("{}捕鱼".format(self.name))


class FlyDog(Dog):

    def __init__(self, name, age, color, job):
        """
        # 先调用父类的构造方法，设置name, age, color这三个属性，然后再添加一个job属性
        # 对父类的拓展，java中叫做派生
        :param name:
        :param age:
        :param color:
        :param job:
        """
        super().__init__(name, age, color)
        self.job = job

    def fly(self):
        print("{}会飞".format(self.name))

    def sleep(self):
        """
        #  重写  当定义了一个跟父类相同的方法名时，会覆盖父类的方法，父类的方法将不会被执行
        # 首先检查自身有没有这个方法，如果没有就去父类查找
        :return:
        """
        print("{}不睡觉".format(self.name))

    def eat(self):  # 拓展
        super().eat()
        print("{}吃蟠桃".format(self.name))


dog = FlyDog("哮天犬", 10000, "金色", "守护天庭")
dog.bark()
dog.fly()
dog.sleep()  # 首先检查自身有没有这个方法，如果没有就去父类查找
dog.eat()



