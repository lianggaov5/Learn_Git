# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/4/19 20:08
@Author   :gaoiang
@Email    :337901080@qq.com
@File     :py_class.py
@Software :PyCharm
********************************
"""


class Person:
    head = 1    # 类属性

    def __init__(self, name, age):  # self表示对象本身
        self.name = name
        self.age = age

    @classmethod  # 类方法 目的：修改类属性
    def test_1(cls):  # cls 表示类本身
        cls.head = 5  # 推荐使用

    @classmethod  # 类方法 目的：修改类属性
    def test_2(cls):  # cls 表示类本身
        cls.head = 5  # 推荐使用
        cls.test_1()

    @staticmethod
    def test():
        Person.head = 1

    def test_3(self):
        Person.head = 1
        self.age = 18


Person.test_1()  # 推荐使用
person1 = Person("Jack", 18)
person2 = Person("lemon", 20)
print(person1.head)
person2.head = 2
print(person2.head)
Person.head = 3
print(Person.head)

# b = "hello"
# list_1 = [1, 3]
# list_2 = [1, 3]
# list_3 = list_1
# print(list_1 is list_2)
# print(list_1 is list_3)
# print(a is b)
