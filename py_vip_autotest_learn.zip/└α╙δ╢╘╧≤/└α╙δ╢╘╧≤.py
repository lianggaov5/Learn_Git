# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/4/24 15:46
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :类与对象.py
@Software :PyCharm
********************************
"""


class User:

    """
    define a user class
    """
    def __init__(self, name, gender, phone, user_id, address):
        self.name = name
        self.gender = gender
        self.phone = phone
        self.id = user_id
        self.address = address

    def run(self):
        print("{}喜欢跑步！".format(self.name))

    def listen_to_music(self):
        print("{}喜欢听音乐".format(self.name))

    def __str__(self):
        return "<{}>".format(self.name)


user1 = User("小简", "女", "15556075395", "3415", "深圳")
user1.listen_to_music()
print(user1)
