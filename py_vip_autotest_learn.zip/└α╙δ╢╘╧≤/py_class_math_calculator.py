# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/4/20 11:19
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :py_class_math_calculator.py
@Software :PyCharm
********************************
"""


class MathCalculator:

    def __init__(self, num1, num2):
        self.num1 = num1
        self.num2 = num2

    def add(self):
        return self.num1 + self.num2

    def sub(self):
        return self.num1 - self.num2

    def mul(self):
        return self.num1 * self.num2

    def div(self):
        return self.num1 / self.num2


if __name__ == "__main__":
    mc = MathCalculator(1, 2)
    try:
        print(mc.add())
        print(mc.sub())
        print(mc.mul())
        print(mc.div())
    except ValueError:
        print("传递数字类型错误！")
    except ZeroDivisionError:
        print("零除错误！")
    except Exception as e:
        print("其它错误：{}".format(e))
