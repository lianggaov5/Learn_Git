"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/18 8:08
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :lemon_0513_homework_04.py
@Software :PyCharm
********************************
"""
# 4.完成如下程序
# a.将Excel操作进行封装
# b.Excel操作封装之后，将之前写的两数相除的单元测试再次进行重构
import unittest
import inspect
# from collections import namedtuple

from ddt import ddt, data

# 将数据从excel中读取出来，在Python中来处理
# from openpyxl import load_workbook  # 可以对已存在的excel进行读写操作

from unittest单元测试.py_unittest_math_operation_01 import MathOperation
from lemon_20190513_rewrite_unittest.excel_handle_rewrite_unittest_01 import HandleExcl


@ddt
class TestMul(unittest.TestCase):
    """
    测试两数相乘
    """
    case_obj = HandleExcl("div_cases.xlsx", "divide")
    cases_list = case_obj.get_cases()  # 获取所有的用例，返回一个嵌套命名元组的列表

    @classmethod
    def setUpClass(cls):
        """
        重写父类的类方法，在实例方法执行之前会被调用一次
        在所有用例执行之前会被执行
        :return:
        """
        print("\n{:=^40s}".format("开始执行用例"))
        cls.file_name = "record_run_results_div.txt"
        print("打开【{}】文件".format(cls.file_name))
        cls.file = open(cls.file_name, mode="a", encoding="utf-8")
        cls.file.write("\n{:=^40s}\n".format("开始执行用例"))

    @classmethod
    def tearDownClass(cls):
        """
        重写父类的类方法
        所有用例执行之后，会被调用一次
        :return:
        """
        print("{:=^40s}".format("用例执行结束"))
        cls.file.write("{:=^40s}\n".format("用例执行结束"))
        print("关闭【{}】文件".format(cls.file_name))
        cls.file.close()

    @data(*cases_list)   # 装饰实例方法
    def test_two_positive_mul(self, data_namedtuple):
        # 查看当前运行的实例方法名称，用例根据实例方法名按照ascii码顺序运行
        # 单元测试中实例方法执行的时候，如果抛出异常，那么这个实例方法会终止执行，
        # 有for循环的话，代码一直执行，直到抛出异常结束
        print("\nRunning Test Method:{}".format(inspect.stack()[0][3]))
        case_id = data_namedtuple.case_id
        msg = data_namedtuple.title
        l_data = data_namedtuple.l_data
        r_data = data_namedtuple.r_data
        expect_result = data_namedtuple.expected

        real_result = MathOperation(l_data, r_data).div()
        # ws.cell(case_id+1, 6).value = real_result

        try:
            self.assertEqual(real_result, expect_result, msg="测试{}失败".format(msg))
        except AssertionError as e:
            print("具体异常信息为{}".format(e))
            self.file.write("{},执行结果:{}\n具体异常信息:{}\n".format(msg, "fail", e))
            self.case_obj.write_case(row=case_id+1, actual=real_result, result="Fail")
            # ws.cell(row=case_id+1, column=7, value="Fail")
            raise e
        else:
            self.file.write("{},执行结果:{}\n".format(msg, "pass"))
            self.case_obj.write_case(row=case_id + 1, actual=real_result, result="Pass")


if __name__ == "__main__":
    unittest.main()



