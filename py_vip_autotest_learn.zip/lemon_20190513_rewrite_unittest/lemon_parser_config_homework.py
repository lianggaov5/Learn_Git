"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/18 8:31
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :lemon_parser_config_homework.py
@Software :PyCharm
********************************
"""
from configparser import ConfigParser


class ConfigMsg:

    def __init__(self):
        self.config = ConfigParser()
        self.read_file = self.config.read("test_case.conf", encoding="utf-8")


# path = ConfigMsg().config.get("file path", "cases_path")
# print(path)




