"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/17 21:24
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :lemon_01_log_handle.py
@Software :PyCharm
********************************
"""
#  痛点：
# 1.记录的信息不全面，比如没有时间信息，没有执行人的信息，日志等级、日志详细信息
# 2.文件记录的信息比较混乱，不方便使用脚本统计
# 3.当日志文件比较大的时候，没有自动进行日志轮转功能
# 基于这些问题，怎么解决呢？
# 使用日志器

# 日志收集器的日志等级：NOTSET(0)、DEBUG(10)、INFO(20)、WARNING(30)、ERROR(40)、CRITICAL(5)
# 日志等级比当前日志等级高的都能收集，比他低的都不能收集

# 日志输出渠道：console终端、文件、smtp、http请求  （handles）
# 日志输出渠道的日志等级：日志等级比当前日志等级高的都能收集，比他低的都不能收集
# 日志显示格式; formatter
import logging  # python系统自带的
# 补充：默认有一个root根收集器，使用的日志等级为warning
# 从低到高
# logging.debug("这是debug日志")
# logging.info("这是info日志")
# logging.warning("这是warning日志")
# logging.error("这是error日志")
# logging.critical("这是critical日志")

# 1.定义日志收集器
# 返回logging对象
case_logger = logging.getLogger("logger_name")  # 如果name不传参，默认使用root日志收集器

# 2.定义日志收集器的的等级
case_logger.setLevel(logging.DEBUG)  # 往往等级比较低

# 3.定义日志输出渠道
# 可以指定多个渠道
# Handler对象
# 输出到console控制台
console_handle = logging.StreamHandler()

# 输出到文件中
file_handle = logging.FileHandler("cases.log", encoding="utf-8")

# 4.指定日志输出渠道的日志等级
# console_handle.setLevel("ERROR")   #
console_handle.setLevel(logging.ERROR)  # 如果都不能被日志收集器收集的日志，一定没办法输出到渠道中
file_handle.setLevel(logging.INFO)

# 5.定义日志显示的格式
# 简单日志格式
simple_formatter = logging.Formatter("%(asctime)s - [%(levelname)s] - [日志信息]:%(message)s")
# 复杂的日志格式
ver_formatter = logging.Formatter("%(asctime)s - [%(levelname)s] - %(module)s  - %(name)s"
                                  " - [行数]:%(lineno)d - [日志信息]:%(message)s")
console_handle.setFormatter(simple_formatter)  # 设置终端的日志为简单格式
file_handle.setFormatter(ver_formatter)     # 设置文件的日志为复杂格式

# 6. 对接， 将日志器收集器与输出渠道进行对接
case_logger.addHandler(console_handle)
case_logger.addHandler(file_handle)

if __name__ == '__main__':
    case_logger.debug("这是debug日志")
    case_logger.info("这是info日志")
    case_logger.warning("这是warning日志")
    case_logger.error("这是error日志")
    case_logger.critical("这是critical日志")
pass

