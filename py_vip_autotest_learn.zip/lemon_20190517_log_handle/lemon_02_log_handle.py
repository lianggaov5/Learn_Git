# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/5/23 23:42
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :lemon_02_log_handle.py
@Software :PyCharm
********************************
"""
# 痛点：所有的文件都保存在一个文件中，真的没问题么？
# 2.日志文件会无限大
# 3.历史悠久的文件还有价值么？
# 为了解决问题（轮询日志、限制单个文件的大小）RotatingFileHandler来替代 日志渠道
# 按日期保存文件，定时删除相应文件
import logging  # python系统自带的
# from logging.handlers import TimedRotatingFileHandler  # 按时间轮询
from logging.handlers import RotatingFileHandler       # 文件大小轮询


# 1.定义日志收集器
# 返回logging对象
case_logger = logging.getLogger("logger_name")  # 如果name不传参，默认使用root日志收集器

# 2.定义日志收集器的的等级
case_logger.setLevel(logging.DEBUG)  # 往往等级比较低

# 3.定义日志输出渠道
# 可以指定多个渠道
# Handler对象
# 输出到console控制台
console_handle = logging.StreamHandler()

# 输出到文件中
# file_handle = logging.FileHandler("cases.log", encoding="utf-8")
# backupCount：日志文件的数量   maxBytes：一个日志文件最大的字节数  1kb = 1024b
file_handle = RotatingFileHandler("cases.log", maxBytes=1024, backupCount=3, encoding="utf-8")

# 4.指定日志输出渠道的日志等级
# console_handle.setLevel("ERROR")   #
console_handle.setLevel(logging.ERROR)  # 如果都不能被日志收集器收集的日志，一定没办法输出到渠道中
file_handle.setLevel(logging.INFO)

# 5.定义日志显示的格式
# 简单日志格式
simple_formatter = logging.Formatter("%(asctime)s - [%(levelname)s] - [日志信息]:%(message)s")
# 复杂的日志格式
ver_formatter = logging.Formatter("%(asctime)s - [%(levelname)s] - %(module)s  - %(name)s"
                                  " - [行数]:%(lineno)d - [日志信息]:%(message)s")
console_handle.setFormatter(simple_formatter)  # 设置终端的日志为简单格式
file_handle.setFormatter(ver_formatter)     # 设置文件的日志为复杂格式

# 6. 对接， 将日志器收集器与输出渠道进行对接
case_logger.addHandler(console_handle)
case_logger.addHandler(file_handle)

if __name__ == '__main__':
    for _ in range(1000):
        case_logger.debug("这是debug日志")
        case_logger.info("这是info日志")
        case_logger.warning("这是warning日志")
        case_logger.error("这是error日志")
        case_logger.critical("这是critical日志")
pass






