# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/6/13 12:29
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :test01.py
@Software :PyCharm
********************************
"""
from suds.client import Client

# 这里是你的webservice访问地址
user_url = "http://120.24.235.105:9010/sms-service-war-1.0/ws/smsFacade.ws?wsdl"
client = Client(user_url)  # Client里面直接放访问的URL，可以生成一个webservice对象
print(client)  # 打印所webservice里面的所有接口方法名称



