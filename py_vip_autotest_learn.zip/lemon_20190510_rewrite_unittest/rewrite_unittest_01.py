"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/1 8:52
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :math_operation_test_case.py
@Software :PyCharm
********************************
"""
# 重构之前的单元测试
# 先导入系统模块
import unittest
import inspect
from collections import namedtuple
# 将数据从excel中读取出来，在Python中来处理
# 导入第三方模块
from openpyxl import load_workbook # 可以对已存在的excel进行读写操作
# 导入自定义模块
from unittest单元测试.py_unittest_math_operation_01 import MathOperation

# 1.打开excel文件
wb = load_workbook("test_cases.xlsx")

# 2.定位表单
ws = wb["multiply"]

# 3.定位单元格
# 获取第一行表头的信息
sheet_head_tuple = tuple(ws.iter_rows(max_row=1, values_only=True))[0]

cases_list = []
cases = namedtuple("cases", sheet_head_tuple, rename=True)  # 创建一个命名元组的类cases，并赋值给cases
for data in ws.iter_rows(min_row=2, values_only=True):
    cases_list.append(cases(*data))  # cases(*data)：创建一个对象即命名元组，*data表示元组拆包


class TestMul(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        """
        重写父类的类方法，在实例方法执行之前会被调用一次
        在所有用例执行之前会被执行
        :return:
        """
        print("\n{:=^40s}".format("开始执行用例"))
        cls.file_name = "record_run_results1.txt"
        print("打开【{}】文件".format(cls.file_name))
        cls.file = open(cls.file_name, mode="a", encoding="utf-8")
        cls.file.write("\n{:=^40s}\n".format("开始执行用例"))

    @classmethod
    def tearDownClass(cls):
        """
        重写父类的类方法
        所有用例执行之后，会被调用一次
        :return:
        """
        print("{:=^40s}".format("用例执行结束"))
        cls.file.write("{:=^40s}\n".format("用例执行结束"))
        print("关闭【{}】文件".format(cls.file_name))
        cls.file.close()
        wb.save('test_cases.xlsx')

    def test_two_positive_mul(self):
        # 查看当前运行的实例方法名称，用例根据实例方法名按照ascii码顺序运行
        # 单元测试中实例方法执行的时候，如果抛出异常，那么这个实例方法会终止执行，
        # 有for循环的话，代码一直执行，直到抛出异常结束
        print("\nRunning Test Method:{}".format(inspect.stack()[0][3]))
        for one_case in cases_list:
            data_namedtuple = one_case
            case_id = data_namedtuple.case_id
            msg = data_namedtuple.title
            l_data = data_namedtuple.l_data
            r_data = data_namedtuple.r_data
            expect_result = data_namedtuple.expected

            real_result = MathOperation(l_data, r_data).mul()
            ws.cell(case_id+1, 6).value = real_result

            try:
                self.assertEqual(real_result, expect_result, msg="测试{}失败".format(msg))
            except AssertionError as e:
                print("具体异常信息为{}".format(e))
                self.file.write("{},执行结果:{}\n具体异常信息:{}\n".format(msg, "fail", e))
                ws.cell(row=case_id+1, column=7, value="Fail")
                raise e
            else:
                self.file.write("{},执行结果:{}\n".format(msg, "pass"))
                ws.cell(row=case_id+1, column=7, value="Pass")

    # def test_two_negative_mul(self):
    #     # 查看当前运行的实例方法名称
    #     print("\nRunning Test Method:{}".format(inspect.stack()[0][3]))
    #
    #     data_namedtuple = cases_list.pop(0)
    #     case_id = data_namedtuple.case_id
    #     msg = data_namedtuple.title
    #     l_data = data_namedtuple.l_data
    #     r_data = data_namedtuple.r_data
    #     expect_result = data_namedtuple.expected
    #
    #     real_result = MathOperation(l_data, r_data).mul()
    #     ws.cell(case_id + 1, 6).value = real_result
    #
    #     try:
    #         self.assertEqual(real_result, expect_result, msg="测试{}失败".format(msg))
    #     except AssertionError as e:
    #         print("具体异常信息为{}".format(e))
    #         self.file.write("{},执行结果:{}\n具体异常信息:{}\n".format(msg, "fail", e))
    #         ws.cell(row=case_id + 1, column=7, value="Fail")
    #         raise e
    #     else:
    #         self.file.write("{},执行结果:{}\n".format(msg, "pass"))
    #         ws.cell(row=case_id + 1, column=7, value="Pass")
    #
    # def test_positive_negative_mul(self):
    #     # 查看当前运行的实例方法名称
    #     print("\nRunning Test Method:{}".format(inspect.stack()[0][3]))
    #     data_namedtuple = cases_list.pop(0)
    #     case_id = data_namedtuple.case_id
    #     msg = data_namedtuple.title
    #     l_data = data_namedtuple.l_data
    #     r_data = data_namedtuple.r_data
    #     expect_result = data_namedtuple.expected
    #
    #     real_result = MathOperation(l_data, r_data).mul()
    #     ws.cell(case_id + 1, 6).value = real_result
    #
    #     try:
    #         self.assertEqual(real_result, expect_result, msg="测试{}失败".format(msg))
    #     except AssertionError as e:
    #         print("具体异常信息为{}".format(e))
    #         self.file.write("{},执行结果:{}\n具体异常信息:{}\n".format(msg, "fail", e))
    #         ws.cell(row=case_id + 1, column=7, value="Fail")
    #         raise e
    #     else:
    #         self.file.write("{},执行结果:{}\n".format(msg, "pass"))
    #         ws.cell(row=case_id + 1, column=7, value="Pass")
    #
    # def test_zero_zero_mul(self):
    #     # 查看当前运行的实例方法名称
    #     print("\nRunning Test Method:{}".format(inspect.stack()[0][3]))
    #     data_namedtuple = cases_list.pop(0)
    #     case_id = data_namedtuple.case_id
    #     msg = data_namedtuple.title
    #     l_data = data_namedtuple.l_data
    #     r_data = data_namedtuple.r_data
    #     expect_result = data_namedtuple.expected
    #
    #     real_result = MathOperation(l_data, r_data).mul()
    #     ws.cell(case_id + 1, 6).value = real_result
    #
    #     try:
    #         self.assertEqual(real_result, expect_result, msg="测试{}失败".format(msg))
    #     except AssertionError as e:
    #         print("具体异常信息为{}".format(e))
    #         self.file.write("{},执行结果:{}\n具体异常信息:{}\n".format(msg, "fail", e))
    #         ws.cell(row=case_id + 1, column=7, value="Fail")
    #         raise e
    #     else:
    #         self.file.write("{},执行结果:{}\n".format(msg, "pass"))
    #         ws.cell(row=case_id + 1, column=7, value="Pass")


if __name__ == "__main__":
    unittest.main()
