# -*- coding: utf-8 -*-
"""
-------------------------------------------------
  @Time : 2019/5/10 20:24
  @Auth : 可优
  @File : lemon_01_rewrite_unittest_1.py
  @IDE  : PyCharm
  @Motto: ABC(Always Be Coding)
-------------------------------------------------
"""
# 重构之前的单元测试
import unittest
import inspect
from collections import namedtuple

# 将数据从Excel中读取出来，在Python中来处理
from openpyxl import load_workbook  # 可以对已存在的excel进行读写操作

# 导入自定义模块
from unittest单元测试.py_unittest_math_operation_01 import MathOperation  # 再导入自定义模块

# 1、打开excel文件（已存在）
wb = load_workbook('test_cases.xlsx')

# 2、定位表单
ws = wb.active  # 获取第一个表单

# 3、定位单元格
sheet_head_tuple = tuple(ws.iter_rows(max_row=1, values_only=True))[0]

cases_list = []
Cases = namedtuple("Cases", sheet_head_tuple)   # 创建一个元组类
for data in ws.iter_rows(min_row=2, values_only=True):  # 每次遍历，返回由某行所有单元格值组成的一个元组
    cases_list.append(Cases(*data))


class TestMulti(unittest.TestCase):
    """
    测试两数相乘
    """
    @classmethod
    def setUpClass(cls):
        """
        重写父类的类方法，在实例方法执行之前会被调用一次
        在所有用例执行之前会被执行
        :return:
        """
        print("\n{:=^40s}".format("开始执行用例"))
        cls.file_name = "record_run_results1.txt"
        print("打开【{}】文件".format(cls.file_name))
        cls.file = open(cls.file_name, mode="a", encoding="utf-8")
        cls.file.write("\n{:=^40s}\n".format("开始执行用例"))

    @classmethod
    def tearDownClass(cls):
        """
        重写父类的类方法
        所有用例执行之后，会被调用一次
        :return:
        """
        print("{:=^40s}".format("用例执行结束"))
        cls.file.write("{:=^40s}\n".format("用例执行结束"))
        print("关闭【{}】文件".format(cls.file_name))
        cls.file.close()
        wb.save('test_cases.xlsx')

    def test_negatives_multi(self):
        """
        两个负数相乘
        :return:
        """
        # 通过inspect查看当前运行的实例方法名称
        print("\nRunning Test Method: {}".format(inspect.stack()[0][3]))
        for one_case in cases_list:    # 使用循环来实现
            data_namedtuple = one_case
            case_id = data_namedtuple.case_id
            msg = data_namedtuple.title
            l_data = data_namedtuple.l_data
            r_data = data_namedtuple.r_data
            expected = data_namedtuple.expected

        # data_namedtuple = cases_list.pop(0)
        # case_id = data_namedtuple.case_id
        # msg = data_namedtuple.title
        # l_data = data_namedtuple.l_data
        # r_data = data_namedtuple.r_data
        # expected = data_namedtuple.expected

        # 获取两个负数相乘的实际结果
            real_result = MathOperation(l_data, r_data).multiply()
            # 将实际结果写入excel
            ws.cell(row=case_id+1, column=6, value=real_result)
            try:
                self.assertEqual(expected, real_result, msg="测试{}失败".format(msg))
            except AssertionError as e:
                print("具体异常为：{}".format(e))
                self.file.write("{}，执行结果为：{}\n具体异常为：{}\n".format(msg, "Fail", e))  # 将执行失败的信息写入到文件
                ws.cell(row=case_id+1, column=7, value="Fail")
                raise e
            else:
                ws.cell(row=case_id + 1, column=7, value="Pass")
                self.file.write("{}，执行结果为：{}\n".format(msg, "Pass"))  # # 将执行成功的信息写入到文件

    # @unittest.skip("test_neg_pos_multi")
    # def test_neg_pos_multi(self):
    #     """
    #     一个负数与一个正数相乘
    #     :return:
    #     """
    #     print("\nRunning Test Method: {}".format(inspect.stack()[0][3]))
    #     data_namedtuple = cases_list.pop(0)
    #     case_id = data_namedtuple.case_id
    #     msg = data_namedtuple.title
    #     l_data = data_namedtuple.l_data
    #     r_data = data_namedtuple.r_data
    #     expected = data_namedtuple.expected
    #
    #     # 获取两个负数相乘的实际结果
    #     real_result = MathOperation(l_data, r_data).multiply()
    #     # 将实际结果写入excel
    #     ws.cell(row=case_id + 1, column=6, value=real_result)
    #     try:
    #         self.assertEqual(expected, real_result, msg="测试{}失败".format(msg))
    #     except AssertionError as e:
    #         print("具体异常为：{}".format(e))
    #         self.file.write("{}，执行结果为：{}\n具体异常为：{}\n".format(msg, "Fail", e))  # 将执行失败的信息写入到文件
    #         ws.cell(row=case_id + 1, column=7, value="Fail")
    #         raise e
    #     else:
    #         ws.cell(row=case_id + 1, column=7, value="Pass")
    #         self.file.write("{}，执行结果为：{}\n".format(msg, "Pass"))  # # 将执行成功的信息写入到文件
    #
    # def test_two_zero(self):
    #     """
    #     两个零相乘
    #     :return:
    #     """
    #     print("\nRunning Test Method: {}".format(inspect.stack()[0][3]))
    #     data_namedtuple = cases_list.pop(0)
    #     case_id = data_namedtuple.case_id
    #     msg = data_namedtuple.title
    #     l_data = data_namedtuple.l_data
    #     r_data = data_namedtuple.r_data
    #     expected = data_namedtuple.expected
    #
    #     # 获取两个负数相乘的实际结果
    #     real_result = MathOperation(l_data, r_data).multiply()
    #     # 将实际结果写入excel
    #     ws.cell(row=case_id + 1, column=6, value=real_result)
    #     try:
    #         self.assertEqual(expected, real_result, msg="测试{}失败".format(msg))
    #     except AssertionError as e:
    #         print("具体异常为：{}".format(e))
    #         self.file.write("{}，执行结果为：{}\n具体异常为：{}\n".format(msg, "Fail", e))  # 将执行失败的信息写入到文件
    #         ws.cell(row=case_id + 1, column=7, value="Fail")
    #         raise e
    #     else:
    #         ws.cell(row=case_id + 1, column=7, value="Pass")
    #         self.file.write("{}，执行结果为：{}\n".format(msg, "Pass"))  # # 将执行成功的信息写入到文件
    #
    # def test_two_pos_muti(self):
    #         """
    #         两个正数相乘
    #         :return:
    #         """
    #         print("\nRunning Test Method: {}".format(inspect.stack()[0][3]))
    #         data_namedtuple = cases_list.pop(0)
    #         case_id = data_namedtuple.case_id
    #         msg = data_namedtuple.title
    #         l_data = data_namedtuple.l_data
    #         r_data = data_namedtuple.r_data
    #         expected = data_namedtuple.expected
    #
    #         # 获取两个负数相乘的实际结果
    #         real_result = MathOperation(l_data, r_data).multiply()
    #         # 将实际结果写入excel
    #         ws.cell(row=case_id + 1, column=6, value=real_result)
    #         try:
    #             self.assertEqual(expected, real_result, msg="测试{}失败".format(msg))
    #         except AssertionError as e:
    #             print("具体异常为：{}".format(e))
    #             self.file.write("{}，执行结果为：{}\n具体异常为：{}\n".format(msg, "Fail", e))  # 将执行失败的信息写入到文件
    #             ws.cell(row=case_id + 1, column=7, value="Fail")
    #             raise e
    #         else:
    #             ws.cell(row=case_id + 1, column=7, value="Pass")
    #             self.file.write("{}，执行结果为：{}\n".format(msg, "Pass"))  # # 将执行成功的信息写入到文件


if __name__ == '__main__':
    unittest.main()
