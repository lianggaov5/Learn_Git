"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/16 22:50
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :rewrite_unittest_02.py
@Software :PyCharm
********************************
"""
# 第一次的重构有哪些痛点呢？
# 1.每个实例方法(每条用例)代码完全一致，代码冗余极其严重，不符合优秀程序员的特质
# 2.这种设计中，excel中的用例数量与单元测试实例方法数目一致，如果不一致会报错，程序拓展性极差
# 3.对excel进行读写的操作，可读性非常差，效率也比较低，程序封装性不好
# 4.代码不够灵活，代码很难重用

# ddt，是一种数据驱动的思想，是一个辅助加载测试用例的库
# 单元测试中实例方法执行的时候，如果抛出异常，那么这个实例方法会终止执行，
# 有for循环的话，代码一直执行，直到抛出异常结束
import unittest
import inspect
from ddt import ddt, data

test_cases = (1, 2, 3, 0, False, None, "")   # 模拟测试数据


@ddt   # ddt是用来装饰类的，需要与data装饰器一起使用，所谓装饰器就是给类或函数添加额外的功能
class TestCase01(unittest.TestCase):
    """
    使用ddt来加载测试数据
    """
    @data(*test_cases)  # 将序列类型拆包为多个位置参数
    def test_case(self, val):
        print("\nRunning Test Method:{}".format(inspect.stack()[0][3]))
        print("值为：{}\n类型：{}\n".format(val, type(val)))
        self.assertTrue(val)


if __name__ == '__main__':
    unittest.main()

# 执行了多条测试用例，用例执行的条数与data装饰器的（位置）参数个数一致
# 每执行一条用例，会自动将一个参数传给val,当最后一个参数传给val,且用例执行结束之后，程序执行完毕
# 这个过程相当于遍历参数
# ddt和data要一起使用
