"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/17 11:12
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :lemon_0510_homework_4.py
@Software :PyCharm
********************************
"""
import unittest
import inspect
from collections import namedtuple

from ddt import ddt, data
from openpyxl import load_workbook

from unittest单元测试.py_unittest_math_operation_01 import MathOperation   # 类由开发写

wb = load_workbook("div_cases.xlsx")
ws = wb["divide"]
sheet_head_tuple = tuple(ws.iter_rows(min_row=1, values_only=True))[0]
cases = namedtuple("cases", sheet_head_tuple)
cases_list = []
for row_tuple_value in ws.iter_rows(min_row=2, values_only=True):
    cases_list.append(cases(*row_tuple_value))


@ddt
class TestDiv(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        """
        重写父类的类方法，在实例方法执行之前会被调用一次
        在所有用例执行之前会被执行
        :return:
        """
        print("\n{:=^40s}".format("开始执行用例"))
        cls.file_name = "record_run_results_div.txt"
        print("打开【{}】文件".format(cls.file_name))
        cls.file = open(cls.file_name, mode="a", encoding="utf-8")
        cls.file.write("\n{:=^40s}\n".format("开始执行用例"))

    @classmethod
    def tearDownClass(cls):
        """
        重写父类的类方法
        所有用例执行之后，会被调用一次
        :return:
        """
        print("{:=^40s}".format("用例执行结束"))
        cls.file.write("{:=^40s}\n".format("用例执行结束"))
        print("关闭【{}】文件".format(cls.file_name))
        cls.file.close()
        wb.save('div_cases.xlsx')

    @data(*cases_list)
    def test_case(self, data_namedtuple):
        print("\nRunning Test Method:{}".format(inspect.stack()[0][3]))
        case_id = data_namedtuple.case_id
        msg = data_namedtuple.title
        l_data = data_namedtuple.l_data
        r_data = data_namedtuple.r_data
        expect_result = data_namedtuple.expected

        real_result = MathOperation(l_data, r_data).div()
        ws.cell(case_id + 1, 6).value = real_result

        try:
            self.assertEqual(real_result, expect_result, msg="测试{}失败".format(msg))
        except AssertionError as e:
            print("具体异常信息为{}".format(e))
            self.file.write("{},执行结果:{}\n具体异常信息:{}\n".format(msg, "fail", e))
            ws.cell(row=case_id + 1, column=7, value="Fail")
            self.assertRaises(ZeroDivisionError)   # 断言异常
            raise e
        else:
            self.file.write("{},执行结果:{}\n".format(msg, "pass"))
            ws.cell(row=case_id + 1, column=7, value="Pass")


if __name__ == '__main__':
    unittest.main()



