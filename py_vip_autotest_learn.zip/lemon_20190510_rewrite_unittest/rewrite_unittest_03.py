"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/17 10:16
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :rewrite_unittest_03.py
@Software :PyCharm
********************************
"""
# 使用@unpack装饰器来进一步拆包
import unittest
import inspect
from ddt import ddt, data, unpack


@ddt   # ddt是用来装饰类的，需要与data装饰器一起使用，所谓装饰器就是给类或函数添加额外的功能
class TestCase01(unittest.TestCase):
    """
    使用ddt来加载测试数据
    """
    # @data(*test_cases)  # 将序列类型拆包为多个位置参数
    @data([True, False, None], ("可优", "柠檬小姐姐", 0), 10)
    # @unpack  # 使用unpack时，所有的元素要能支持拆包才行，序列类型可以拆包（list、tuple） 不推荐使用
    def test_case(self, val):
        print("\nRunning Test Method:{}".format(inspect.stack()[0][3]))
        print("值为：{}\n类型：{}\n".format(val, type(val)))
        self.assertTrue(val)


if __name__ == '__main__':
    unittest.main()

# 执行了多条测试用例，用例执行的条数与data装饰器的（位置）参数个数一致
# 每执行一条用例，会自动将一个参数传给val,当最后一个参数传给val,且用例执行结束之后，程序执行完毕
# 这个过程相当于遍历参数
# ddt和data要一起使用

