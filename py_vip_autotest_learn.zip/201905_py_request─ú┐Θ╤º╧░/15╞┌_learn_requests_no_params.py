"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/7 16:40
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :15期_learn_requests_no_params.py
@Software :PyCharm
********************************
"""
# python的第三方库比较多，所以比java简单
# 安装pip install requests
# 作用是什么？发送http请求
# 你常见的http请求有哪几种？ get/post
# 为什么要学习它？ 要做的项目：http协议的接口

# request:客户端发送给服务器的一个请求，包含：请求头、请求地址、请求参数、http协议版本
# response: 服务器对客户端的请求的响应，包含：响应头、响应报文、状态码、cookie信息
# 常见的http请求状态码
# 200：请求成功  404：请求地址不存在  500：服务器内部错误
# 502：网管错误  302：请求被重定向  304：缓存未修改，无需再次传输请求的内容，如静态资源：如png、jpg、gif、js、css
import requests
url = "http://www.lemfix.com"
# 模拟客户端发送1个get请求
# resp = requests.get(url)  # 响应结果消息实体   包含：响应头 响应报文 状态码
# print("响应头：{}".format(resp.headers))  # 响应头
# print("响应报文：{}".format(resp.text))  # 响应报文
# print("响应报文：{}".format(resp.status_code))  # 相应状态码
# 模拟客户端发送1个post请求
resp = requests.post(url)
print("响应头：{}".format(resp.headers))  # 响应头
print("响应报文：{}".format(resp.text))  # 响应报文
print("响应报文：{}".format(resp.status_code))  # 相应状态码

