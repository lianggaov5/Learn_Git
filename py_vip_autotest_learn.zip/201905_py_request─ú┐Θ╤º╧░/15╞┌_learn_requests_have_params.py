"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/7 21:40
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :15期_learn_requests_have_params.py
@Software :PyCharm
********************************
"""
# 作业安排
# 写一个类：里面有一个函数http_request能够完成get请求或post请求，要求有返回值
# 每个请求要求有请求参数
# 登录请求地址：http://192.168.122.128:8080/futureloan/mvc/api/member/login
# mobilephone:15556075391    pwd:gl123456
import requests
login_url = "http://192.168.122.128:8080/futureloan/mvc/api/member/login"
param = {"mobilephone": "15556075391", "pwd": "gl123456"}
# 发送一个get请求，如果请求有参数的话，就要以字典的形式传递过去
# resp = requests.get(login_url, params=param)
# print("响应头：{}".format(resp.headers))  # 响应头
# print("响应报文：{}".format(resp.text))  # 响应报文
# print("响应报文：{}".format(resp.status_code))  # 相应状态码
# 发送一个post请求,接口文档中是否说明以json格式传递，如无,则是data格式
resp = requests.post(login_url, data=param)
print("响应头：{}".format(resp.headers))  # 响应头
print("响应报文：{}".format(resp.text))  # 响应报文
print("响应报文：{}".format(resp.status_code))  # 相应状态码

d1 = {"mobilephone": "15556075391", "pwd": "gl123456", 'data': None}  # 字典  数据为空时，字典为None
d2 = '{"mobilephone": "15556075391", "pwd": "gl123456", "data":null}'  # json格式的字符串 数据为空时，为null

import json
print(json.loads(d2))  # 将json格式的字符串转换成字典
