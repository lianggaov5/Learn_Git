"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/7 22:47
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :15期_learn_requests_homework.py
@Software :PyCharm
********************************
"""
# 作业安排
# 写一个类：里面有一个函数http_request能够完成get请求或post请求，要求有返回值
# 每个请求要求有请求参数
# 登录请求地址：http://192.168.122.128:8080/futureloan/mvc/api/member/login
# mobilephone:15556075391    pwd:gl123456
import requests


class HttpRequest:

    def __init__(self, url, data, method):
        self.url = url
        self.data = data
        self.method = method

    def http_request(self):
        if self.method.lower() == "get":
            resp_1 = requests.get(self.url, self.data)
            print("响应报文：{}".format(resp_1.text))
            # return self.get_request
        else:
            resp_1 = requests.get(self.url, self.data)
            print("响应报文：{}".format(resp_1.text))
            # return self.post_request
        return resp_1

    # def get_request(self):
    #     resp = requests.get(self.url, self.data)
    #     print(resp.status_code)
    #     print(resp.text)
    #     print(resp.headers)
    #
    # def post_request(self):
    #     resp = requests.get(self.url, self.data)
    #     print(resp.status_code)
    #     print(resp.text)
    #     print(resp.headers)


if __name__ == "__main__":
    login_url = "http://192.168.122.128:8080/futureloan/mvc/api/member/login"
    param = {"mobilephone": "15556075391", "pwd": "gl123456"}
    resp = HttpRequest(login_url, param, "get").http_request()

