# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/5/24 21:32
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :handle_json.py
@Software :PyCharm
********************************
"""
import json

# 1.对象结构
# json格式的数据以字符串的形式显示
data_json = '{"status": 1,"code": "10001","data": null,"msg": "注册成功"}'
# 将json格式的数据转换为python中字典类型的数据
data_dict = json.loads(data_json)
print(data_dict)

# 2. 数组结构 （多个json数据在数组中）
some_data_json = '[{"status": 1,"code": "10001","data": null,"msg": "注册成功"},' \
                 '{"status": 2,"code": "10001","data": null,"msg": "注册成功"},' \
                 '{"status": 3,"code": "10001","data": null,"msg": "注册成功"},' \
                 '{"status": 4,"code": "10001","data": null,"msg": "注册成功"}]'
nested_dict_list = json.loads(some_data_json)
print(nested_dict_list)
print(nested_dict_list[1]["code"])

# 将python中的字典类型转换成json
one_dict_data = {"name": "gl", "age": 18, "hobby": None}
one_json = json.dumps(one_dict_data)
print(one_json)

# 将嵌套字典的列表转换成json
one_list = [{"name": "gl", "age": 18, "hobby": None}, {"name": "gl", "age": 18, "hobby": None}, ]
another_json = json.dumps(one_list)
pass
