# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/5/30 12:11
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :handle_json_02.py
@Software :PyCharm
********************************
"""
import json

# 1.从文件中读取json格式的数据
with open("one_json_file.txt", encoding="utf8") as file:
    one_dict = json.load(file)
print(one_dict)

# 2. 将json格式的数据写入到文件中
with open("two_json_file.txt", "w", encoding="utf8") as file:
    json.dump(one_dict, file)