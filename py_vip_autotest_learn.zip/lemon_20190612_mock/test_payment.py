# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/6/12 20:35
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :test_payment.py
@Software :PyCharm
********************************
"""
# mock应用场景：当相应模块未进行开发完成，又需要用到该模块才能进行测试时
# mock作用：模拟相应方法的返回值
# mock用法：
# self.payment.auth = mock.Mock(return_value=200)   返回值200
# self.payment.auth = mock.Mock(side_effect=[TimeoutError, 200])  mock超时，返回值200
# side_effect可以为序列类型，异常类型、对象，
# 如果是序列类型，每次调用mock对象，会依次将side_effect中的元素返回
import unittest
from unittest import mock

from lemon_20190612_mock.payment import Payment


class PaymentTest(unittest.TestCase):
    """
    测试支付接口
    """
    def setUp(self):
        self.payment = Payment()

    def test_sucess(self):
        """
        测试支付成功
        :return:
        """
        # mock作用：模拟相应方法的返回值
        self.payment.auth = mock.Mock(return_value=200)
        res = self.payment.pay(user_id=1001, card_num="123456", amount=3000)
        self.assertEqual("success", res)

    def test_fail(self):
        """
        测试支付失败
        :return:
        """
        self.payment.auth = mock.Mock(return_value=500)
        res = self.payment.pay(user_id=1002, card_num="123456", amount=2000)
        self.assertEqual("fail", res)

    def test_retry_success(self):
        """
        测试调用第三方接口超时之后，再次支付成功
        :return:
        """
        # 第一次支付超时，第二次支付成功
        self.payment.auth = mock.Mock(side_effect=[TimeoutError, 200])
        res = self.payment.pay(user_id=1003, card_num="123456", amount=3000)
        self.assertEqual("success", res)

    def test_retry_fail(self):
        """
        测试调用第三方接口超时之后，再次支付失败
        :return:
        """
        # 第一次支付超时，第二次支付成功
        # side_effect可以为序列类型，异常类型、对象，
        # 如果是序列类型，每次调用mock对象，会依次将side_effect中的元素返回
        self.payment.auth = mock.Mock(side_effect=[TimeoutError, 500])
        res = self.payment.pay(user_id=1004, card_num="123456", amount=4000)
        self.assertEqual("fail", res)


if __name__ == '__main__':
    unittest.main()



