"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/17 12:21
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :handle_excel.py
@Software :PyCharm
********************************
"""
import unittest
import inspect

from lemon_20190603_finance_api_test.libs.ddt import ddt, data

from lemon_20190603_finance_api_test.scripts.handle_excel import HandleExcel
from lemon_20190603_finance_api_test.scripts.handle_config import do_config
from lemon_20190603_finance_api_test.scripts.handle_log import do_log
from lemon_20190603_finance_api_test.scripts.handle_request import HandleRequest
from lemon_20190603_finance_api_test.scripts.constants import TEST_DATA_FILE_PATH
from lemon_20190603_finance_api_test.scripts.handle_context import Context




@ddt
class TestRegister(unittest.TestCase):
    """
    测试注册功能
    """
    do_excel = HandleExcel(TEST_DATA_FILE_PATH, "register")
    cases_list = do_excel.get_cases()  # 获取所有的用例，返回一个嵌套命名元组的列表

    @classmethod
    def setUpClass(cls):
        """
        重写父类的类方法，在实例方法执行之前会被调用一次
        在所有用例执行之前会被执行
        :return:
        """
        cls.send_request = HandleRequest()
        do_log.info("\n{:=^40s}".format("开始执行注册功能用例"))

    @classmethod
    def tearDownClass(cls):
        """
        重写父类的类方法
        所有用例执行之后，会被调用一次
        :return:
        """
        cls.send_request.close()
        do_log.info("\n{:=^40s}\n".format("注册功能用例执行结束"))

    @data(*cases_list)   # 装饰实例方法
    def test_register(self, data_namedtuple):
        """
        测试注册功能
        :param data_namedtuple:
        :return:
        """
        print("\nRunning Test Method:{}".format(inspect.stack()[0][3]))
        do_log.info("\nRunning Test Method:{}".format(inspect.stack()[0][3]))

        new_url = do_config.get("project", "url") + data_namedtuple.url
        new_data = Context().register_parameter(data_namedtuple.datas)
        method = data_namedtuple.method

        response = self.send_request(method=method,
                                     url=new_url,
                                     data=new_data)  # 接口不支持json格式，只支持form表单，is_json=False

        run_success_msg = do_config("msg", "success_result")
        run_fail_msg = do_config("msg", "fail_result")

        print("expect_result:{}".format(data_namedtuple.expected))
        print("real_result:{}".format(response.text))

        try:
            self.assertEqual(response.text, data_namedtuple.expected, msg="测试{}注册失败".format(data_namedtuple.title))
        except AssertionError as e:
            print("具体异常信息为{}".format(e))
            do_log.error("{},执行结果:{}\n具体异常信息:{}\n".format(data_namedtuple.title, run_fail_msg, e))
            self.do_excel.write_case(row=data_namedtuple.case_id+1,
                                     actual=response.text,
                                     result=run_fail_msg)
            raise e
        else:
            self.do_excel.write_case(row=data_namedtuple.case_id+1,
                                     actual=response.text,
                                     result=run_success_msg)


if __name__ == "__main__":
    unittest.main()

