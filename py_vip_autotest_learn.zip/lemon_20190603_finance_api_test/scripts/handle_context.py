# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/6/7 13:40
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :handle_context.py
@Software :PyCharm
********************************
"""
import re

from lemon_20190603_finance_api_test.scripts.handle_mysql import HandleMysql
from lemon_20190603_finance_api_test.scripts.handle_config import HandleConfig
from lemon_20190603_finance_api_test.scripts.constants import CONFIGS_USER_FILE_PATH

do_config = HandleConfig(CONFIGS_USER_FILE_PATH)


class Context:
    """
    实现参数化、反射功能
    """
    not_existed_tel_pattern = re.compile(r"\$\{not_existed_tel\}")
    existed_tel_pattern = re.compile(r"\$\{invest_user_tel\}")
    not_existed_regname_pattern = re.compile(r"\$\{not_existed_regname\}")

    def not_existed_tel_replace(self, data):
        """
        替换未注册的手机号
        :param data:
        :return:
        """
        do_mysql = HandleMysql()
        # 查询pattern模式对象是否在原始字符串中存在
        if re.search(self.not_existed_tel_pattern, data):
            # 生成未注册的手机号
            not_existed_tel = do_mysql.create_not_existed_phone()
            # sub中第一个参数为pattern模式对象,第二个参数为需要替换的值,第三个参数为原始字符串
            data = re.sub(self.not_existed_tel_pattern, not_existed_tel, data)

        do_mysql.close()
        return data

    def existed_tel_replace(self, data):
        """
        替换已经注册的手机号
        :param data:
        :return:
        """
        do_mysql = HandleMysql()
        # 查询pattern模式对象是否在原始字符串中存在
        if re.search(self.existed_tel_pattern, data):
            # sub中第一个参数为pattern模式对象,第二个参数为需要替换的值,第三个参数为原始字符串
            data = re.sub(self.existed_tel_pattern, str(do_config("invest_user", "mobilephone")), data)

        do_mysql.close()
        return data

    def register_parameter(self, data):
        """
        实现注册功能的参数化
        :param self:
        :param data:
        :return:
        """
        # 先替换的未注册的手机号
        data = self.not_existed_tel_replace(data)
        # 再替换已注册的手机号
        data = self.existed_tel_replace(data)

        return data

    def login_parameter(self, data):
        """
        实现登陆功能的参数化
        :param data:
        :return:
        """
        # 先替换的未注册的手机号
        data = self.not_existed_tel_replace(data)
        # 再替换已注册的手机号
        data = self.existed_tel_replace(data)

        return data

    def recharge_parameter(self, data):
        """
        实现登陆功能的参数化
        :param data:
        :return:
        """
        # 先替换的未注册的手机号
        data = self.not_existed_tel_replace(data)
        # 再替换已注册的手机号
        data = self.existed_tel_replace(data)

        return data


if __name__ == '__main__':
    target_str1 = '{"mobilephone":"${not_existed_phone}","pwd":"123456","regname":"Tom"}'
    target_str2 = '{"mobilephone":"${invest_user_tel}","pwd":"123456","regname":""}'
    one_context = Context()
    # print(one_context.register_parameter(target_str1))
    print(one_context.existed_tel_replace(target_str2))
    pass

