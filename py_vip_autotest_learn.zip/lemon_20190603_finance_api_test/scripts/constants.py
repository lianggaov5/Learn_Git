# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/5/31 20:28
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :constants.py
@Software :PyCharm
********************************
"""
import os


# __file__固定变量
os.path.abspath(__file__)
os.path.dirname(os.path.abspath(__file__))

# 获取项目目录根路径
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 获取测试数据datas所在的路径
DATAS_DIR = os.path.join(BASE_DIR, "datas")
TEST_DATA_FILE_PATH = os.path.join(DATAS_DIR, "test_cases.xlsx")
print(TEST_DATA_FILE_PATH)

# 获取配置文件configs所在的路径
CONFIGS_DIR = os.path.join(BASE_DIR, "configs")
CONFIGS_FILE_PATH = os.path.join(CONFIGS_DIR, "test_case.conf")
CONFIGS_USER_FILE_PATH = os.path.join(CONFIGS_DIR, "user_accounts.conf")

# 获取日志logs所在的路径
LOGS_DIR = os.path.join(BASE_DIR, "logs")
TEST_LOGS_FILE_PATH = os.path.join(LOGS_DIR, "cases.log")

# 获取报告reports所在的路径
REPORTS_DIR = os.path.join(BASE_DIR, "reports")


# 获取测试用例cases所在的路径
CASES_DIR = os.path.join(BASE_DIR, "cases")

