# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/5/23 23:42
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :lemon_02_log_handle.py
@Software :PyCharm
********************************
"""
import logging  # python系统自带的
# from logging.handlers import TimedRotatingFileHandler  # 按时间轮询
from logging.handlers import RotatingFileHandler       # 文件大小轮询
from lemon_20190603_finance_api_test.scripts.handle_config import do_config
from lemon_20190603_finance_api_test.scripts.constants import TEST_LOGS_FILE_PATH


class HandleLog:
    """
    封装处理日志的类
    """
    # 1.定义日志收集器
    # 返回logging对象

    def __init__(self):
        self.case_logger = logging.getLogger(do_config("log", "logger_name"))  # 如果name不传参，默认使用root日志收集器

    # 2.定义日志收集器的的等级
        self.case_logger.setLevel(do_config("log", "logger_level"))  # 往往等级比较低

    # 3.定义日志输出渠道
    # 可以指定多个渠道
    # Handler对象
    # 输出到console控制台
        console_handle = logging.StreamHandler()

    # 输出到文件中
    # file_handle = logging.FileHandler("cases.log", encoding="utf-8")
    # backupCount：日志文件的数量   maxBytes：一个日志文件最大的字节数  1kb = 1024b
        file_handle = RotatingFileHandler(TEST_LOGS_FILE_PATH,
                                          do_config("log", "maxBytes", is_eval=True),
                                          do_config("log", "backupCount", is_eval=True),
                                          encoding="utf-8")

    # 4.指定日志输出渠道的日志等级
    # console_handle.setLevel("ERROR")   #
        # 如果都不能被日志收集器收集的日志，一定没办法输出到渠道中
        console_handle.setLevel(do_config("log", "console_level"))
        file_handle.setLevel(do_config("log", "file_level"))

    # 5.定义日志显示的格式
    # 简单日志格式
        simple_formatter = logging.Formatter(do_config("log", "simple_formatter"))
    # 复杂的日志格式
        ver_formatter = logging.Formatter(do_config("log", "ver_formatter"))
        console_handle.setFormatter(simple_formatter)  # 设置终端的日志为简单格式
        file_handle.setFormatter(ver_formatter)     # 设置文件的日志为复杂格式

    # 6. 对接， 将日志器收集器与输出渠道进行对接
        self.case_logger.addHandler(console_handle)
        self.case_logger.addHandler(file_handle)

    def get_logger(self):
        """
        返回case_logger对象
        :return:
        """
        return self.case_logger


do_log = HandleLog().get_logger()

if __name__ == '__main__':
    case_logger = HandleLog().get_logger()
    for _ in range(10):
        # case_logger.debug("这是debug日志")
        # case_logger.info("这是info日志")
        # case_logger.warning("这是warning日志")
        case_logger.error("这是error日志")
        # case_logger.critical("这是critical日志")
pass






