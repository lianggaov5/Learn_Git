# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/6/12 10:36
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :learn.py
@Software :PyCharm
********************************
"""
import string
import random

one_str = string.digits   # "0123456789"
last_eight = "".join(random.sample(one_str, 8))   # 从序列one_str中随机选出8位，再拼接成字符串
print(last_eight)
