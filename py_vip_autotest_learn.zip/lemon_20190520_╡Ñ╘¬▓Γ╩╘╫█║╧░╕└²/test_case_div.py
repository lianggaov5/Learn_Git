"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/17 12:21
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :handle_excel.py
@Software :PyCharm
********************************
"""
# 如何来封装一些操作
# 1.明确需求（读取所有的测试用例、读取一条测试用例、写入结果）
# 2.把一些写死的数据提取出来，往往当作属性
# 3.如果其它实例方法中需要调用实例方法中的变量，那么需要将其定义为属性


import unittest
import inspect
# from collections import namedtuple

from lemon_20190520_单元测试综合案例.ddt import ddt, data

# 将数据从excel中读取出来，在Python中来处理
# from openpyxl import load_workbook  # 可以对已存在的excel进行读写操作

from lemon_20190520_单元测试综合案例.test_math_operation import MathOperation
from lemon_20190520_单元测试综合案例.handle_excel import HandleExcel
from lemon_20190520_单元测试综合案例.handle_config import do_config
from lemon_20190520_单元测试综合案例.handle_log import do_log


@ddt
class TestDiv(unittest.TestCase):
    """
    测试两数相除
    """
    do_excel = HandleExcel(do_config("file_path", "cases_path"), "divide")
    cases_list = do_excel.get_cases()  # 获取所有的用例，返回一个嵌套命名元组的列表

    @classmethod
    def setUpClass(cls):
        """
        重写父类的类方法，在实例方法执行之前会被调用一次
        在所有用例执行之前会被执行
        :return:
        """
        do_log.info("\n{:=^40s}".format("开始执行用例"))

    @classmethod
    def tearDownClass(cls):
        """
        重写父类的类方法
        所有用例执行之后，会被调用一次
        :return:
        """
        do_log.info("\n{:=^40s}\n".format("用例执行结束"))

    @data(*cases_list)   # 装饰实例方法
    def test_two_positive_div(self, data_namedtuple):
        # 查看当前运行的实例方法名称，用例根据实例方法名按照ascii码顺序运行
        # 单元测试中实例方法执行的时候，如果抛出异常，那么这个实例方法会终止执行，
        # 有for循环的话，代码一直执行，直到抛出异常结束
        print("\nRunning Test Method:{}".format(inspect.stack()[0][3]))
        do_log.info("\nRunning Test Method:{}".format(inspect.stack()[0][3]))
        case_id = data_namedtuple.case_id
        msg = data_namedtuple.title
        l_data = data_namedtuple.l_data
        r_data = data_namedtuple.r_data
        expect_result = data_namedtuple.expected

        real_result = MathOperation(l_data, r_data).div()
        # ws.cell(case_id+1, 6).value = real_result
        run_success_msg = do_config("msg", "success_result")
        run_fail_msg = do_config("msg", "fail_result")
        try:
            self.assertEqual(real_result, expect_result, msg="测试{}失败".format(msg))
        except AssertionError as e:
            print("具体异常信息为{}".format(e))
            do_log.error("{},执行结果:{}\n具体异常信息:{}\n".format(msg, run_fail_msg, e))
            self.do_excel.write_case(row=case_id+1, actual=real_result, result=run_fail_msg)
            raise e
        else:
            self.do_excel.write_case(row=case_id + 1, actual=real_result, result=run_success_msg)


if __name__ == "__main__":
    unittest.main()

