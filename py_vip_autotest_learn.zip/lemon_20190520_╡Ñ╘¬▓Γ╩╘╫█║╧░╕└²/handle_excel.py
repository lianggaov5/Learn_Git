"""
-*- coding: utf-8 -*-
********************************
@Time     :2019/5/17 12:21
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :handle_excel.py
@Software :PyCharm
********************************
"""
from collections import namedtuple
from openpyxl import load_workbook
from lemon_20190520_单元测试综合案例.handle_config import do_config
# 如果想在其它实例方法中调用，就定义成一个属性，self.属性名


class HandleExcel:

    def __init__(self, file_name, sheet_name=None):
        self.file_name = file_name
        self.sheet_name = sheet_name
        self.wb = load_workbook(self.file_name)
        if self.sheet_name is None:
            self.ws = self.wb.active
        else:
            self.ws = self.wb[sheet_name]
        self.sheet_head_tuple = tuple(self.ws.iter_rows(min_row=1, values_only=True))[0]
        self.cases = namedtuple("cases", self.sheet_head_tuple)
        self.cases_list = []

    def get_cases(self):

        for data in self.ws.iter_rows(min_row=2,  values_only=True):
            self.cases_list.append(self.cases(*data))

        return self.cases_list

    def get_case(self, row):

        if isinstance(row, int) and (1 <= row <= self.ws.max_row):
            return tuple(self.ws.iter_rows(min_row=row, max_row=row, values_only=True))[0]
        else:
            return None

    def write_case(self, row, actual, result):
        if isinstance(row, int) and (2 <= row <= self.ws.max_row):
            self.ws.cell(row, do_config("excel", "actual_col")).value = actual
            self.ws.cell(row, do_config("excel", "result_col")).value = result
            self.wb.save(self.file_name)


do_excel = HandleExcel(do_config("file_path", "cases_path"), "multiply")

if __name__ == '__main__':
    filename = "test_cases.xlsx"
    sheet = "divide"
    one_excel = HandleExcel(filename, sheet)
    cases = one_excel.get_cases()
    print(cases)

    case = one_excel.get_case(2)
    print(case)

    one_excel.write_case(2, -3, "Fail")
    print(case)






