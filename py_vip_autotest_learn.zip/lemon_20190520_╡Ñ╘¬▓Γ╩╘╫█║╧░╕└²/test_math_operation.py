# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/4/24 22:25
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :py_unittest_math_operation_04.py
@Software :PyCharm
********************************
"""


class MathOperation:

    def __init__(self, num1, num2):
        self.num1 = num1
        self.num2 = num2

    def add(self):
        """
        计算两个数的和
        :return:
        """
        return self.num1 + self.num2

    def sub(self):
        """
        计算两个数的差
        :return:
        """
        return self.num1 - self.num2

    def mul(self):
        """
        计算两个数的乘积
        :return:
        """
        return self.num1 * self.num2

    def div(self):
        """
        计算两个数的相除
        :return:
        """
        try:
            self.num2 == 0
        except ZeroDivisionError as e:
            print("{}".format(e))
        else:
            return self.num1 / self.num2


if __name__ == "__main__":
    mo = MathOperation(1, 2)
    print(mo.add())
    print(mo.sub())
    print(mo.mul())
    print(mo.div())

