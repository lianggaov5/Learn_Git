# -*- coding: utf-8 -*-
"""
********************************
@Time     :2019/5/31 11:36
@Author   :gaoliang
@Email    :337901080@qq.com
@File     :mysql_01.py
@Software :PyCharm
********************************
"""
# 需要使用第三方库pymysql
import pymysql


# 1.建立连接
connect = pymysql.connect(
                host="test.lemonban.com",
                user="test",
                password="test",
                db="future",
                port=3306,
                charset="utf8",
                cursorclass=pymysql.cursors.DictCursor
                )

# 2.创建游标
cursor = connect.cursor()

# 3.执行sql语句
sql2 = "select * from member limit 0, 10;"
sql1 = "select * from member where LeaveAmount > %s limit 0, 10;"  # %s 防止sql注入
# cursor.execute(sql)
cursor.execute(sql1, args=(800,))   # args为序列类型
# 需要手动提交sql
connect.commit()

# 获取执行sql语句执行的结果
result_1 = cursor.fetchone()  # 返回所有记录中第一条记录组成的字典
result_2 = cursor.fetchall()  # 返回所有记录中组成的嵌套字典的列表
print(result_1)
print(result_2)

# 4.关闭连接
cursor.close()   # 先关游标
connect.close()  # 然后再关闭连接对象
